package com.example.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;







import com.example.constants.Constants;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.example.stemplet1.R;
import com.example.util.Util;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;



public class HttpRequest {
private final static String TAG = "httpRequest";
	
	private boolean isCancel;
	private Context mContext;
	private final String SD_PAHT = Environment.getExternalStorageDirectory().getAbsolutePath();
	private final String FILE_NAME = "kidp_cover_download.txt";
	private HttpUrlConnectionAsyncTask mhttpAsyncTask;
	private HttpResponseCallback mHttpResponseCallback;
	private String dialog_msg;
	
	//get
	/**
	 * 서버 요청 GET 방식
	 * 
	 * @param context
	 * @param method
	 * @param url
	 * @param callback
	 */
	public void request(Context context, String method, String url, HttpResponseCallback callback){
		mHttpResponseCallback = callback;
		mContext = context;
		
		request(context, new String[] {method, url});
	}
	
	//post
	/**
	 * 서버 요청 POST 방식
	 * 
	 * @param context
	 * @param method
	 * @param url
	 * @param params
	 * @param callback
	 */
	public void request(Context context, String method, String url, String params, HttpResponseCallback callback){
		mHttpResponseCallback = callback;
		mContext = context;
		
		request(context, new String[] {method, url, params});
	}
	
	//request
	private void request(Context context, String... params) {
		mContext = context;
		if (Util.isNetworkConnect(context)) {
			mhttpAsyncTask = new HttpUrlConnectionAsyncTask();
			mhttpAsyncTask.execute(params);
		} else {
			mHttpResponseCallback.onFail(Constants.ERROR_CODE_NETWORK_DISCONNECT);
		}
	}
	
	//cancel
	public void requestCancel(){
		isCancel = true;
		
		if(mhttpAsyncTask != null){
			mhttpAsyncTask.cancel(true);
		}
	}
	
	//https 인증
	private final HostnameVerifier hostnameVerifier = new HostnameVerifier() {
		@Override
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	};
	


	//Http통신 스레드
	private class HttpUrlConnectionAsyncTask extends AsyncTask<String, Integer, String>{
		@Override
		protected void onCancelled() {
			Log.e(TAG, "onCancelled");
			mHttpResponseCallback.onCancel();
		}
		
		@Override
		protected void onPreExecute() {
			isCancel = false;
		}
		
		@Override
		protected String doInBackground(String... params) {
			Log.d(TAG, "doing.......background..........");
			String response=null;
			HttpURLConnection conn =null;
			try {
				String method = params[0];
				
				//url 생성
				URL url = new URL(params[1]);
				
				//URL 연결
				if(url.getProtocol().equalsIgnoreCase("https")){
//					trustAllHosts();
				
					HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
					https.setHostnameVerifier(hostnameVerifier);
					
					conn = https;
				}else{
					Log.d(TAG, "http connection openConnection");
					conn = (HttpURLConnection) url.openConnection();
				}
				//연결 세팅 
				conn.setConnectTimeout(Constants.HTTP_CONN_TIMEOUT);
				
				conn.setReadTimeout(Constants.HTTP_READ_TIMEOUT);
				
				conn.setRequestMethod(method);
				
				conn.setRequestProperty("Accept", "application/json");
				
				conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				
				conn.setDefaultUseCaches(false);
				
				if(method.equals(Constants.HTTP_POST)){				
					conn.setDoOutput(true);
					
					conn.setChunkedStreamingMode(0);
					
					OutputStream os = new BufferedOutputStream(conn.getOutputStream());
					
					os.write(params[2].getBytes());
					
					os.flush();
					
					os.close();
				}else{
					conn.setDoOutput(false);
				}
				
				int responseCode = conn.getResponseCode();
				Log.d(TAG, String.valueOf(responseCode));
				
				if(isCancel){
					response = String.valueOf(Constants.ERROR_CODE_USER_CANCEL);
				}else{
					if(responseCode == HttpURLConnection.HTTP_OK){
						//서버 요청 성공시 데이타 세팅 
						Log.d(TAG, "responseCode Success");
						InputStream inputStream = new BufferedInputStream(conn.getInputStream());
						response = inputStreamToString(inputStream);
					}else{
						//서버 요청 실패시 에러 코드 
						response = String.valueOf(responseCode);
						InputStream inputStream = new BufferedInputStream(conn.getInputStream());
						String error = inputStreamToString(inputStream);
						Log.e(TAG, "error message : "+error);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(conn != null){
					conn.disconnect();
				}
			}
			return response;
		}
		
		@Override
		protected void onPostExecute(String response) {
			super.onPostExecute(response);
			if(TextUtils.isEmpty(response)){
				mHttpResponseCallback.onFail(Constants.ERROR_CODE_UNKNOWN);
			}else if(response.equals(String.valueOf(Constants.ERROR_CODE_USER_CANCEL))){
				mHttpResponseCallback.onCancel();
			}else if(TextUtils.isDigitsOnly(response)){
				mHttpResponseCallback.onFail(Integer.parseInt(response));
			}else{
				mHttpResponseCallback.onSuccess(response);
			}
		}
	}
	//gzip 압축된 data 해제 
	private String inputStreamToString(InputStream inputStream){
		Log.d(TAG, "inputStreamTostring");
		StringWriter writer = new StringWriter();
		BufferedReader reader =null;
		try {
			if(inputStream != null){
				char[]buffer = new char[1024];
				reader = new BufferedReader(new InputStreamReader(inputStream));
				
				int count;
				while ((count = reader.read(buffer))!= -1) {
					writer.write(buffer,0,count);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try{
				if(inputStream != null){
					inputStream.close();
				}
				if(reader != null){
					reader.close();
				}
			}catch(IOException ie){
				ie.printStackTrace();
			}
		}
//		BufferedReader in  = new 
		return writer.toString();
	}
	// 서버 요청 콜백(리스너)
	public interface HttpResponseCallback{
		public void onCancel();
		
		public void onFail(int errorCode);
		
		public void onSuccess(String response);
	}
}
