package com.example.stemplet1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.aes256decoder.AES256Cipher;
import com.example.broadcast.ShutDownReceiver;
import com.example.constants.Constants;
import com.example.frgment.LoginFragment;
import com.example.http.PostHTTPAsync;
import com.example.util.SharedPreferenceManager;
import com.example.util.Util;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ReceiverCallNotAllowedException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;

import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.constant.PageViewerConstant;
public class LoginActivity extends FragmentActivity implements LoginFragment.OnStartActivityListener
	,LoginFragment.OnWriteAESFileListenter
	,PostHTTPAsync.OnPostExecuteListener
	{
	private LoginFragment loginFragment;
	public static LoginActivity loginActivity;
	public static String mURLScheme;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
        Log.e("Login Acitivity","onCreate");
	
        if (!PageViewerConstant.IsTestMode) {
			Constants.URL_LOG_IN = getString(R.string.login_url);
			Constants.COMPANY_ID = getString(R.string.login_company_id);
			Constants.URL_CONTENTS_DOWN = getString(R.string.contents_down_url);
		}
        
		setLoginDevide();
		loginActivity = this;
	}
        @Override
        protected void onStart() {
            if (getIntent() != null) {
                Uri uri = getIntent().getData();
                if (uri != null) {
                    mURLScheme = uri.toString();
                    PageViewerConstant.URLScheme = mURLScheme;
                    Log.e("LoginActivity", "uri -"+mURLScheme);
                }else{
            Log.e("LoginActivity", "uri null");                    
                }
            }else{
            Log.e("LoginActivity", "getIntent null");
            }
            Log.e("LoginActivity", "onStart");
            super.onStart();
        }
	// 로그인 분할 통신
		public void setLoginDevide(){
			String url = Constants.URL_LOG_IN;
			url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
//			String bundle_id = Constants.TEST_BUNDLE_ID;
			String bundle_id = LoginActivity.this.getPackageName();
			
			HashMap<String, String> params = new HashMap<String, String>();
			params.put("storeBundleId", bundle_id);
			params.put("workPath", "19");
			params.put("ostype", "4");
			
			PostHTTPAsync pj = new PostHTTPAsync(LoginActivity.this, url, Constants.REQUEST_PROCESS_ID_DEVIDELOGIN, LoginActivity.this);
			pj.execute(params);
		}
		
	public void setFragment(){
		loginFragment = LoginFragment.newInstance();
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		transaction.replace(R.id.fragmet_main, loginFragment);
		transaction.commitAllowingStateLoss();
	}
	
	
	public void writeAESFile(String response){
		//String => byteArray
		byte[] jsonByte=response.getBytes();
		//암호화
		byte[] jsonEncode_byte = null;
		try {
			String key = Constants.JSON_ENCODE_KEY;
			jsonEncode_byte=AES256Cipher.AES_Encode(jsonByte, key);
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//파일쓰기
		if(jsonEncode_byte != null){
			String path = Constants.ANDROID_FOLDER+"data"+File.separator+this.getPackageName()+File.separator+Constants.ENCODE_FILE_NAME;
			File encode_json_file = new File(path);
			try {
				FileOutputStream fos = new FileOutputStream(encode_json_file);
				fos.write(jsonEncode_byte);
				fos.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void goMainActivity(boolean notNetwork){
		Intent intent = new Intent(LoginActivity.this, MainActivity.class);
		if(notNetwork == true){
			intent.putExtra("not_network", "Y");
			SharedPreferenceManager.putSharedPreferences("not_network_state", "Y");
		}else{
			intent.putExtra("not_network", "N");
			SharedPreferenceManager.putSharedPreferences("not_network_state", "N");
		}
		LoginActivity.this.startActivity(intent);
		LoginActivity.this.finish();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			this.finish();
			break;
		default:
			break;
		}
		return true;
	}

	@Override
	public void onJsonPostExcute(String processID, String result) {
		// TODO Auto-generated method stub
		if(processID.equals(Constants.REQUEST_PROCESS_ID_DEVIDELOGIN)){
			if(result != null){
				Log.e("LoginDevide", result);
				try {
					JSONArray jsonArr = new JSONArray(result);
					JSONObject Json=jsonArr.getJSONObject(0);
					String resultCode=Json.getString("result");
					if(resultCode.equals("5001")){
						JSONObject jsonObj=Json.getJSONObject("appInfo");
						String loginGB=jsonObj.getString("loginGb");
						//파일쓰기
						String path = "data/data/"+LoginActivity.this.getPackageName()+File.separator+"databases/jsonLoingDevideFile";
						File dataFile = new File(path);
						if(dataFile.exists()){
							dataFile.delete();
						}
						Util.JsonFileWrite(path, result);
						if(loginGB.equals("1")){
							//로그인 사용
							SharedPreferenceManager.putSharedPreferences(Constants.LOGINSTATE, Constants.LOGIN);
							setFragment();
						}else{
							//로그인 미사용
							SharedPreferenceManager.putSharedPreferences(Constants.LOGINSTATE, Constants.NOTLOGIN);
							goMainActivity(false);
						}
					}else{
						String msg=Json.getString("message");
						MsgDialog(msg);
					}
				
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				//파일체크
				String isUseLogin = SharedPreferenceManager.getSharedPreferences(Constants.LOGINSTATE,"");
				if (isUseLogin.equals("")) {
					NetWorkErrorDialog();
				}else{
					if (isUseLogin.equals(Constants.NOTLOGIN)) {
						goMainActivity(false);
					}else{
						String path = "data/data/"+LoginActivity.this.getPackageName()+File.separator+"databases/jsonLoingDevideFile";
						String json=Util.JsonFileRead(path);
						if(json.equals("")){
							//파일 없음
							//메세지
							NetWorkErrorDialog();
						}else{
							try {
								JSONArray jsonArr = new JSONArray(json);
								JSONObject Json=jsonArr.getJSONObject(0);
								String resultCode=Json.getString("result");
								if(resultCode.equals("5001")){
									JSONObject jsonObj=Json.getJSONObject("appInfo");
									String loginGB=jsonObj.getString("loginGb");
									if(loginGB.equals("1")){
										//로그인 사용
										SharedPreferenceManager.putSharedPreferences(Constants.LOGINSTATE, Constants.LOGIN);
										setFragment();
									}else{
										//로그인 미사용
										SharedPreferenceManager.putSharedPreferences(Constants.LOGINSTATE, Constants.NOTLOGIN);
										goMainActivity(false);
									}
								}else{
									String msg=Json.getString("message");
									MsgDialog(msg);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				}
				
				
			}
		}
	}
	
	public void NetWorkErrorDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
		builder.setTitle(LoginActivity.this.getString(R.string.network_error))
		.setMessage(LoginActivity.this.getString(R.string.network_check_noconnect))
		.setCancelable(false)
		.setPositiveButton(LoginActivity.this.getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				LoginActivity.this.finish();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void MsgDialog(String msg){
		AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
		builder.setTitle("STOP")
		.setMessage(msg)
		.setCancelable(false)
		.setPositiveButton(LoginActivity.this.getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				LoginActivity.this.finish();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
}
