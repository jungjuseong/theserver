package com.example.broadcast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.db.DBManager;
import com.clbee.authorviewer.kutil.KUtil;
import com.example.constants.Constants;
import com.example.db.DataBaseHelper;
import com.example.frgment.LoginFragment;
import com.example.http.HttpRequest;
import com.example.http.PostHTTPAsync;
import com.example.module.BookMarkData;
import com.example.stemplet1.LoginActivity;
import com.example.stemplet1.R;
import com.example.util.SharedPreferenceManager;
import com.example.util.Util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

public class ServerResultReceiver extends BroadcastReceiver implements PostHTTPAsync.OnPostExecuteListener{
	private String serverData;
	private HttpRequest serverRequest;
	private HttpRequest LogRequest;
	private HttpRequest BookMarkRequest;
	private DBManager mDbHelper;
	private SQLiteDatabase mDB;
	private SQLiteDatabase db;
	private DataBaseHelper dbHelper;
	private HttpRequest LogOutRequest;
	private Context mContext;
	
	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		mContext = context;
		if(action.equals(context.getPackageName()+".GoResultServer")){
			//서버 데이터 전송
				if(Util.isNetworkConnect(context)){
					serverRequest = new HttpRequest();
					Log.e("aaaaa", "goServer");
					serverData=intent.getStringExtra("serverData");
					setRequestServerData(context);
				}
		}else if(action.equals(context.getPackageName()+".LogOutSever")){
				dbHelper = new DataBaseHelper(context);
				mDbHelper = new DBManager(context);
				db = dbHelper.getWritableDatabase();
				mDB = mDbHelper.getWritableDatabase();
				if(!KUtil.currentPageFileRead(context, "contents").equals("")){
					setRequestLogData(context);
				}
				ArrayList<BookMarkData> bookMarkArr=dbHelper.getBookMark(mDB, "contents");
				if(bookMarkArr.size() > 0){
					setRequestBookMarkData(context);
				}
				setRequestLogOutLogData(context);
			    Intent logout_intent = new Intent(context.getPackageName());
			    logout_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(logout_intent);
                System.exit(0);
		}
	}
	
	public void setRequestServerData(final Context context){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = context.getPackageName();
		String deviceId = getDeviceNumber(context);
		Log.e("DEViceId", deviceId);
		String userSeq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");	
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "5");
		params.put("data", serverData);
		
		PostHTTPAsync pj = new PostHTTPAsync(ServerResultReceiver.this, context,url, Constants.REQUEST_PROCESS_ID_SERVERDATA);
		pj.execute(params);
	}
	
	public void setRequestLogData(final Context context){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = context.getPackageName();
		String deviceId = getDeviceNumber(context);
		Log.e("sendDeviceId", deviceId);
		String userSeq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");		
		String pageGb = KUtil.currentPageFileRead(context, "contents");
		Log.e("sendLastPageGb", pageGb);
		Log.e("currentSavePage", pageGb);
		String data = "lastPage";
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("pageGb", pageGb);
		params.put("dataGb", "3");
		params.put("data", data);
		
		PostHTTPAsync pj = new PostHTTPAsync(ServerResultReceiver.this, context,url, Constants.REQUEST_PROCESS_ID_LASTPAGE);
		pj.execute(params);
	}
		
	public void setRequestBookMarkData(final Context context){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = context.getPackageName();
		String deviceId =getDeviceNumber(context);
		String userSeq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");		
		
		ArrayList<BookMarkData> bookMarkArr=dbHelper.getBookMark(mDB, "contents");
		JSONObject sendJson = new JSONObject();
		try {
		JSONArray array = new JSONArray();
			for(int i=0; i < bookMarkArr.size(); i++){
				BookMarkData data=bookMarkArr.get(i);
					JSONObject obj = new JSONObject();
					obj.put("contentsName", data.getContentsName());
					obj.put("_pageNo", data.get_pageNo());
					obj.put("thumbnailImageName", data.getThumbnailImageName());
					obj.put("time", data.getTime());
					array.put(obj);
				
			}
			sendJson.put("bookmarks", array);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "4");
		params.put("data", sendJson.toString());
		
		PostHTTPAsync pj = new PostHTTPAsync(ServerResultReceiver.this, context,url, Constants.REQUEST_PROCESS_ID_BOOKMARK);
		pj.execute(params);
	}
	
	public void setRequestLogOutLogData(final Context context){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = context.getPackageName();
		String deviceId = getDeviceNumber(context);
		String userSeq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ,"");
		String data = "logout";
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "2");
		params.put("data", data);
		
		PostHTTPAsync pj = new PostHTTPAsync(ServerResultReceiver.this, context,url, Constants.REQUEST_PROCESS_ID_LOGOUT);
		pj.execute(params);
	}
		
	public String getDeviceNumber(Context context){
		String android_id = android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
		return android_id;
	}
	
	public void DeleteAnswerFolder(String path){
		File file = new File(path);
		File[] childFileList = file.listFiles();
		for(File childFile : childFileList){
			if(childFile.isDirectory()){
				DeleteAnswerFolder(childFile.getAbsolutePath());
			}else{
				childFile.delete();
			}
		}
		file.delete();
	}

	@Override
	public void onJsonPostExcute(String processID, String result) {
		// TODO Auto-generated method stub
		if(processID.equals(Constants.REQUEST_PROCESS_ID_SERVERDATA)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					Log.e("serverData", "requestSuccess");
					//Ansewer폴더 삭제
					String path = Environment.getExternalStorageDirectory().getAbsolutePath()
							+File.separator+"Android"+File.separator+"data"+File.separator+mContext.getPackageName()+File.separator+"contents"+File.separator+"Answer";
					File answerDiretory = new File(path);
					if(answerDiretory.isDirectory()){
						DeleteAnswerFolder(path);
					}
				}	
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_LASTPAGE)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				String lastPage=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					//라스트 페이지 파일 삭제
					String path = Environment.getExternalStorageDirectory().getAbsolutePath()
							+File.separator+"Android"+File.separator+"data"+File.separator+mContext.getPackageName()+File.separator+"contents"+File.separator+"currentPage.txt";
					File currentPageFile = new File(path);
					if(currentPageFile.exists()){
						currentPageFile.delete();
					}
				}	
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_BOOKMARK)){
			if(result != null && !result.equals("TimeOut")){
				Log.e("setLogData", result);
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					//삭제
					dbHelper.deleteBookMarkTable(mDB);
				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_LOGOUT)){
			if(result != null && !result.equals("TimeOut")){				
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
				}
			}
		}
	}
}
