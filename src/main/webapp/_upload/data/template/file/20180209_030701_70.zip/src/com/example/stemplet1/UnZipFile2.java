package com.example.stemplet1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import com.clbee.authorviewer.R;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import com.clbee.authorviewer.IntroActivity;
import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.R;
import com.clbee.authorviewer.kutil.KUtil;
import com.clbee.authorviewer.log.MyLog;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.util.Log;

public class UnZipFile2 {
    private String _location;
    private Context mContext;
    private ProgressDialog progressDialog;
    private long fileSize;
    private AlertDialog.Builder alertDialog;
    
    public UnZipFile2(String location, Context context) {
        
    	mContext = context;
        String isSDCard = KUtil.loadString(mContext, "isSDCard");
		
		File[] dirs = ContextCompat.getExternalFilesDirs(mContext, null);
		
		if (isSDCard == null || isSDCard.equals("") || isSDCard.equals("false")) {
			_location = location;
		}else{			
			_location = dirs[1].toString().replace("files", "contents")+File.separator;					
		}
        
        
        
        
    }
    
    
    public boolean newUnZip(String contentsName){
        String packagePath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
        + mContext.getPackageName();
        String destination = packagePath + File.separator + contentsName;
        String source = packagePath + File.separator + "contents.zip";
        String password = "password";
        
        try {
            ZipFile zipFile = new ZipFile(source);
            if (zipFile.isEncrypted()) {
                zipFile.setPassword(password);
            }
            zipFile.extractAll(destination);
            return true;
        } catch (ZipException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean unzip() {
        File contentsFolder = null;
        String localFileName = null;
        
        
        String isSDCard = KUtil.loadString(mContext, "isSDCard");
		
		File[] dirs = ContextCompat.getExternalFilesDirs(mContext, null);
		
		if (isSDCard == null || isSDCard.equals("") || isSDCard.equals("false")) {
			contentsFolder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
                    + mContext.getPackageName() + File.separator);

		}else{			
			contentsFolder = new File(dirs[1].toString().replace("files", ""));					
		}
		localFileName = contentsFolder + File.separator + "contents.zip";        
                        
        File zipFile = new File(localFileName);
        fileSize = zipFile.length();
        
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long bytesAvailable = (long) stat.getFreeBlocks() * (long) stat.getBlockSize();
        if (bytesAvailable < fileSize) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                
                @Override
                public void run() {
                    alertDialog = new AlertDialog.Builder(mContext);
                    alertDialog.setMessage(mContext.getString(R.string.not_enough_storage_space_message)).setPositiveButton(mContext.getString(R.string.ok), new OnClickListener() {
                        
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ((IntroActivity) mContext).finish();
                            System.runFinalizersOnExit(true);
                            System.exit(0);
                        }
                    });
                    alertDialog.show();
                    
                }
            });
            return false;
        } else {
            
            if (zipFile.exists()) {
                try {
                    File f = new File(contentsFolder + File.separator + "contents");
                    if (!f.isDirectory()) {
                        f.mkdirs();
                    }
                    FileInputStream inputStream = new FileInputStream(localFileName);
                    ZipInputStream zipStream = new ZipInputStream(inputStream);
                    ZipEntry zEntry = null;
                    while ((zEntry = zipStream.getNextEntry()) != null) {
                        // Log.d("Unzip", "Unzipping " + zEntry.getName() +
                        // " at "
                        // + _location);
                        
                        if (zEntry.isDirectory()) {
                            _dirChecker(zEntry.getName());
                        } else {
                            FileOutputStream fout = new FileOutputStream(_location + "/" + zEntry.getName());                                                       
                            BufferedInputStream in = new BufferedInputStream(zipStream);                                    
                            BufferedOutputStream bufout = new BufferedOutputStream(fout);                            
                            byte b[] = new byte[1024];
                            int n;
                            while ((n = in.read(b,0,1024)) >= 0) {
                            	bufout.write(b,0,n);
                            }                                    
                            zipStream.closeEntry();
                            bufout.close();
                            fout.close();
                        }
                    }
                    zipStream.close();
                    Log.e("Unzip", "Unzipping complete. path :  " + _location);
                    return true;
                } catch (Exception e) {
                    Log.e("Unzip-Failed", Log.getStackTraceString(e));                    
                }
            }
            return false;
        }
    }
    
    private void _dirChecker(String dir) {
        File f = new File(_location + dir);
        
        if (!f.isDirectory()) {
            f.mkdirs();
        }
    }
    
    private void notifiyProgressChange(final long currentStt) {
        // ((IntroActivity)mContext).mHandler.post(new Runnable() {
        //
        // @Override
        // public void run() {
        // if (currentStt > fileSize) {
        // progressDialog.setProgress((int)fileSize);
        // }else {
        // progressDialog.setProgress((int) currentStt);
        // }
        // }
        //
        // });
    }
    
}