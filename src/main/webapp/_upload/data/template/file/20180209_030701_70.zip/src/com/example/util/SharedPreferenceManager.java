package com.example.util;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceManager {
	private static SharedPreferences sharedPreferences;
	private static SharedPreferences.Editor editor;
	private static String preferencesName = "";
	/**
	 * Preferences init.
	 * 파일이름 설정.
	 */
	public static void init(Context context, String name){
		preferencesName = name;
		sharedPreferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE);
		editor = sharedPreferences.edit();
	}
	
	/**
	 * Preferences 클리
	 */
	public static void clearSharedPreFerences(){
		if(editor != null){
			editor.clear();
			editor.commit();
		}
	}
	
	/**
	 * 
	 * @param key
	 * @param value
	 * 
	 * Preferences String 저장
	 * 
	 */
	public static void putSharedPreferences(String key, String value){
		if(editor != null){
			editor.putString(key, value);
			editor.commit();
		}
	}
	/**
	 * 
	 * @param key
	 * @param value
	 * 
	 * Preferences int 저장
	 */
	public static void putSharedPreferences(String key, int value){
		if(editor != null){
			editor.putInt(key, value);
			editor.commit();
		}
	}
	/**
	 * 
	 * @param key
	 * @param value
	 * 
	 * Preferences long 저장
	 */
	public static void putSharedPreferences(String key, long value){
		if(editor != null){
			editor.putLong(key, value);
			editor.commit();
		}
	}
	
	/**
	 * 
	 * @param key
	 * @param value
	 * 
	 * Preferences boolean 저장
	 */
	public static void putSharedPreferencesBoolean(String key, boolean value){
		if(editor != null){
			editor.putBoolean(key, value);
			editor.commit();
		}
	}
	
	/**
	 * 
	 * @return
	 * 
	 * Preferences name 값
	 */
	public static String getSharedPreferencesName(){
		return preferencesName;
	}
	
	/**
	 * 
	 * @param key
	 * @param defValue
	 * @return
	 * 
	 * Preferences String  return
	 */
	public static String getSharedPreferences(String key, String defValue){
		return sharedPreferences.getString(key, defValue);
	}
	
	/**
	 * 
	 * @param key
	 * @param defValue
	 * @return
	 * 
	 * Preferences int return
	 */
	public static int getSharedPreferences(String key, int defValue){
		return sharedPreferences.getInt(key, defValue);
	}
	/**
	 * 
	 * @param key
	 * @param defValue
	 * @return
	 * 
	 * Preferences long return
	 * 
	 */
	public static long getSharedPreferences(String key, long defValue){
		return sharedPreferences.getLong(key, defValue);
	}
	/**
	 * 
	 * @param key
	 * @param defValue
	 * @return
	 * 
	 * Preferences boolean return
	 */
	public static boolean getSharedBoolean(String key, boolean defValue){
		return sharedPreferences.getBoolean(key, defValue);
	}
	
	public static void deleteSharedPreferences(String key){
		if(editor != null){
			editor.remove(key);
			editor.commit();
		}
	}
}
