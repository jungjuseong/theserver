package com.example.db;

import java.util.ArrayList;

import com.example.constants.Constants;
import com.example.module.BookMarkData;
import com.kic.util.TextUtil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.text.TextUtils;
import android.util.Log;

public class DataBaseHelper extends SQLiteOpenHelper{
	private final String TAG = this.getClass().getSimpleName();
	
	public DataBaseHelper(Context context) {
		super(context,Constants.DATABASE_NAME, null, Constants.DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		Log.e(TAG, "onCreate()");		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		if(oldVersion == 1){
		}
	}
	
	public ArrayList<BookMarkData> getBookMark(SQLiteDatabase db, String booksName){
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT ");
		sql.append("contentsName,");
		sql.append("_pageNo,");
		sql.append("thumbnailImageName,");
		sql.append("time ");
		sql.append("FROM "+"bookmark_tbl"+" ");
		sql.append("WHERE "+"contentsName"+" = '"+booksName+"'");
		Log.e("aaaaaa", sql.toString());
		
		Cursor cursor = db.rawQuery(sql.toString(), null);
		
		ArrayList<BookMarkData> items=BookMarkData.getDBookMarkInfo(cursor);
		cursor.close();
		
		return items;
	}
	
	public boolean insertBookMarkData(SQLiteDatabase db, BookMarkData bookMarkInfo){
		ContentValues values = new ContentValues();
		if(!TextUtils.isEmpty(bookMarkInfo.getContentsName())){
			values.put("contentsName", bookMarkInfo.getContentsName());
		}
		
		values.put("_pageNo", bookMarkInfo.get_pageNo());
		
		if(!TextUtils.isEmpty(bookMarkInfo.getThumbnailImageName())){
			values.put("thumbnailImageName", bookMarkInfo.getThumbnailImageName());
		}
		
		if(!TextUtils.isEmpty(bookMarkInfo.getTime())){
			values.put("time", bookMarkInfo.getTime());
		}
		
		long result = -1;
		try{
			result = db.insertOrThrow("bookmark_tbl", null, values);
		}catch(SQLiteConstraintException e){
			e.printStackTrace();
		}
		if(result == -1){
			return false;
		}else{
			return true;
		}

	}
	
	public void deleteBookMarkTable(SQLiteDatabase db){
		db.execSQL("delete from bookmark_tbl");
	}
}

 
