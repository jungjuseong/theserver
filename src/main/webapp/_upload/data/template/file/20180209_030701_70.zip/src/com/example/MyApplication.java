package com.example;

import com.example.broadcast.ShutDownReceiver;
import com.example.constants.Constants;
import com.example.util.SharedPreferenceManager;

import android.app.Application;
import android.content.Intent;
import android.content.IntentFilter;

public class MyApplication extends Application{
	@Override
	public void onCreate() {
		super.onCreate();
		SharedPreferenceManager.init(this, getPackageName());
//		setReceiver();
	}
	
	public void setReceiver(){
		IntentFilter intentfilter = new IntentFilter();
		//스크린 off
		intentfilter.addAction(Intent.ACTION_SCREEN_OFF);
		//스크린 온
		intentfilter.addAction(Intent.ACTION_SCREEN_ON);
		//잠금
//		intentfilter.addAction(Intent.ACTION_USER_PRESENT);
		ShutDownReceiver receiver = new ShutDownReceiver();
		registerReceiver(receiver, intentfilter);
	}
}
