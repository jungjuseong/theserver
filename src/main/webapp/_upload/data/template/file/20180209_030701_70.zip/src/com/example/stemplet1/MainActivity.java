package com.example.stemplet1;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.clbee.authorviewer.IntroActivity;
import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.db.DBManager;
import com.clbee.authorviewer.kutil.KUtil;
import com.example.constants.Constants;
import com.example.db.DataBaseHelper;
import com.example.http.HttpRequest;
import com.example.http.PostHTTPAsync;
import com.example.module.BookMarkData;
import com.example.util.SharedPreferenceManager;
import com.example.util.Util;

import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity
	implements PostHTTPAsync.OnPostExecuteListener{
	private ImageView introImage;
	private ProgressDialog mProgressDialog;
	public final int UNZIP_OK = 0;
	public final int PAGE_REDY = 1;
	private final int DOWNLOAD_OK = 11;
	private final int DOWNFILE_EXISTS = 12;
	private final int REQUEST_COMPLETE=13;
	private int requestCount=0;
	private String unZipPath;
	private FileDownLoader2 FileDownLoader2;
	public static final boolean useObb = false;
	private int INTRO_TIME = 500;
	private ProgressDialog unZipProgressDialog;
	private String strScreenType = "Land";
	private HttpRequest getLogRequest;
	private HttpRequest getBookMarkRequest;
	private DBManager mDbHelper;
	private SQLiteDatabase mDB;
	private SQLiteDatabase db;
	private DataBaseHelper dbHelper;
	private String netWorkAction;
	private String lastPage;
	
	public Handler mHandler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case DOWNLOAD_OK:
				unZipProcess();
				break;
			case DOWNFILE_EXISTS:
				unZipProcess();
				break;
			case UNZIP_OK:
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				startActivity();
				break;
			case PAGE_REDY:
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				break;
			case REQUEST_COMPLETE:
				if(requestCount < 1){
					++requestCount;
				}else if(requestCount == 1){
					Intent intent = new Intent(MainActivity.this, PageActivity.class);
					intent.putExtra("BookName", "contents");
					intent.putExtra("ScreenType", strScreenType );
					intent.putExtra("loginType", "Login");
					
					if(lastPage != null){
						intent.putExtra("lastPage", lastPage);
					}else{
						intent.putExtra("lastPage", "0");
					}
					intent.putExtra("isSingleApp", "Y");
					startActivity(intent);
					finish();
				}
				break;
			default:
				break;
			}
			
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		netWorkAction =intent.getExtras().getString("not_network");
		getLogRequest = new HttpRequest();
		getBookMarkRequest = new HttpRequest();
		dbHelper = new DataBaseHelper(this);
		mDbHelper = new DBManager(this);
		db = dbHelper.getWritableDatabase();
		mDB = mDbHelper.getWritableDatabase();
		dbHelper.onCreate(db);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        strScreenType = getApplicationContext().getString(com.example.stemplet1.R.string.SCREEN_ORIENTATION_MODE);
		if (strScreenType.equals("Land") ) {
			this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);	
		}else {
			this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		}
		setContentView(R.layout.intro);
//		findView();
//		setIntroImage();
		setUnZipPath();
		if (useObb) {
			unZipProcess();
		} else {
			contentDownLoadProcess();
		}
	}
	
	private void contentDownLoadProcess() {
		if (dataCheck()) {
			new Handler().postDelayed(new Runnable() {

				@Override
				public void run() {
					startActivity();
				}
			}, INTRO_TIME);
		} else {
			contendsDownLoad();
		}

	}

	private void unZipProcess() {
		if (dataCheck()) {
			new Handler().postDelayed(new Runnable() {

				@Override
				public void run() {
					startActivity();
				}
			}, INTRO_TIME);
		} else {
			// showProgressDialog();
			new Thread(new Runnable() {

				@Override
				public void run() {
					unZipData();
				}
			}).start();
		}
	}

	private void contendsDownLoad() {
		FileDownLoader2 = new FileDownLoader2(MainActivity.this);
		// FileDownLoader2.download("http://221.143.22.213/data/contents1.zip");
	}

	private void setUnZipPath() {
		if (useObb) {
			unZipPath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
					+ getApplicationContext().getPackageName() + File.separator;
		} else {
			unZipPath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
					+ getApplicationContext().getPackageName() + File.separator + "contents" + File.separator;
		}

	}

	private void findView() {
		introImage = (ImageView) findViewById(R.id.intro_img);
	}

	private void setIntroImage() {
		introImage.setImageResource(R.drawable.intro_image);
		// introImage.setScaleType(ScaleType.CENTER_CROP);
	}

	private boolean dataCheck() {
	   boolean isDataExistes = false;
		String isSDCard = KUtil.loadString(MainActivity.this, "isSDCard");
				
		File[] dirs = ContextCompat.getExternalFilesDirs(MainActivity.this, null);
		File unZipDir = null; 
		if (isSDCard == null || isSDCard.equals("") || isSDCard.equals("false")) {
			unZipDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
					+ getApplicationContext().getPackageName() + File.separator + "contents" + File.separator);
		}else{			
			unZipDir = new File(dirs[1].toString().replace("files", "contents"));					
		}
		
		
		

		if (unZipDir.exists()) {
			isDataExistes =  true;
		}

		return isDataExistes;
	}

	private void unZipData() {

		UnZipFile2 unZip = new UnZipFile2(unZipPath, MainActivity.this);
		startUnZipProgress();
		unZip.unzip();
		Message msg = mHandler.obtainMessage();
		msg.what = UNZIP_OK;
		mHandler.sendMessage(msg);

	}

	private void showProgressDialog() {
		String dlgMessage = getString(R.string.unzipping);
		mProgressDialog = new ProgressDialog(this);
		mProgressDialog.setIndeterminate(true);
		mProgressDialog.setMessage(dlgMessage);
		mProgressDialog.setCancelable(false);
		mProgressDialog.show();
	}

	private void startActivity() {
		if(Util.isNetworkConnect(MainActivity.this) && SharedPreferenceManager.getSharedPreferences(Constants.LOGINSTATE, "").equals(Constants.LOGIN)){
			getLogLastPageRequest();
			getBookMarkRequest();
		}else{
			Intent intent = new Intent(MainActivity.this, PageActivity.class);
			intent.putExtra("BookName", "contents");
			intent.putExtra("ScreenType", strScreenType );
			if(SharedPreferenceManager.getSharedPreferences(Constants.LOGINSTATE, "").equals(Constants.LOGIN)){
				intent.putExtra("loginType", Constants.LOGIN);
			}else{
				intent.putExtra("loginType", Constants.NOTLOGIN);
			}
			if(lastPage != null){
				intent.putExtra("lastPage", lastPage);
			}else{
				lastPage = KUtil.loadString(MainActivity.this, "savePage"+"contents");
				intent.putExtra("lastPage", "0");
			}
Log.e("appCalled", "1");
			if (LoginActivity.mURLScheme != null) {
Log.e("appCalled", "2 - "+LoginActivity.mURLScheme);
				intent.putExtra("URLScheme", LoginActivity.mURLScheme);
			}
			intent.putExtra("isSingleApp", "Y");
Log.e("appCalled", "3");
KUtil.saveString(getApplicationContext(), "isCalled", "y");
			startActivity(intent);
			finish();
		}
			
	}
	private static class XAPKFile {
		public final boolean mIsMain;
		public final int mFileVersion;
		public final long mFileSize;

		XAPKFile(boolean isMain, int fileVersion, long fileSize) {
			mIsMain = isMain;
			mFileVersion = fileVersion;
			mFileSize = fileSize;
		}
	}

	private static final XAPKFile[] xAPKS = { new XAPKFile(true, // true
																	// signifies
																	// a main
																	// file
			2, // the version of the APK that the file was uploaded
				// against
			152464348 // the length of the file in bytes
	) };

	private void startUnZipProgress() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				if (unZipProgressDialog == null) {
					unZipProgressDialog = new ProgressDialog(MainActivity.this);
				}
				unZipProgressDialog.setCancelable(false);
				unZipProgressDialog.setMessage(getString(R.string.unzipping));
				unZipProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
				// progressDialog.setProgress(0);
				// progressDialog.setMax((int) fileSize);

				if (!unZipProgressDialog.isShowing()) {
					try {
						unZipProgressDialog.show();
					} catch (Exception e) {
						// TODO: handle exception
					}

				}
			}

		});
	}

	@Override
	protected void onDestroy() {
		if (unZipProgressDialog != null && unZipProgressDialog.isShowing()) {
			unZipProgressDialog.dismiss();
			unZipProgressDialog = null;
		}
		super.onDestroy();
	}
	public void getLogLastPageRequest(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		String bundle_id = MainActivity.this.getPackageName();
		String user_seq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");
		String pageGb = KUtil.loadString(this, "savePage" + "contents");
		Log.e("currentSavePage", pageGb);	
		String dataGb = "lastPage";
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("storeBundleId", bundle_id);
		params.put("workPath", "16");
		params.put("userSeq", user_seq);
		params.put("dataGb", "3");
		params.put("data", dataGb);
				params.put("ostype", "4");
		PostHTTPAsync pj = new PostHTTPAsync(MainActivity.this, url, Constants.REQUEST_PROCESS_ID_GETLASTPAGE, MainActivity.this);
		pj.execute(params);
	}
	
	public void getBookMarkRequest(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		
		String bundle_id = MainActivity.this.getPackageName();
		String user_seq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");
			
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("storeBundleId", bundle_id);
		params.put("workPath", "16");
		params.put("userSeq", user_seq);
		params.put("dataGb", "4");
				params.put("ostype", "4");
		
		PostHTTPAsync pj = new PostHTTPAsync(MainActivity.this, url, Constants.REQUEST_PROCESS_ID_GETBOOKMARK, MainActivity.this);
		pj.execute(params);
	
	}
	
	@Override
	public void onJsonPostExcute(String processID, String result) {
		// TODO Auto-generated method stub
		if(processID.equals(Constants.REQUEST_PROCESS_ID_GETLASTPAGE)){
			if(result != null){
				Log.e("getLogData", result);
				String success=null;
				lastPage=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
					JSONObject logData=responseLog.getJSONObject("logData");
					if(success.equals("5000")){
						if(logData.has("pageGb")){
							lastPage=logData.getString("pageGb");
							KUtil.saveString(MainActivity.this, "savePage"+"contents", lastPage);
						}
						//성공
						if(getLogRequest != null){
							getLogRequest.requestCancel();
							getLogRequest = null;
						}
						mHandler.sendEmptyMessage(REQUEST_COMPLETE);
					}else{
//						Toast.makeText(MainActivity.this, "겟 라스트 페이지 로그데이터 전송 실패.", Toast.LENGTH_LONG).show();
						if(getLogRequest != null){
							getLogRequest.requestCancel();
							getLogRequest = null;
						}
						mHandler.sendEmptyMessage(REQUEST_COMPLETE);
					}	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					Log.e("jsonEception", "aaaaa");
					e.printStackTrace();
				}
			}else{
				Intent intent = new Intent(MainActivity.this, PageActivity.class);
				intent.putExtra("BookName", "contents");
				intent.putExtra("ScreenType", strScreenType );
				if(SharedPreferenceManager.getSharedPreferences(Constants.LOGINSTATE, "").equals(Constants.LOGIN)){
					intent.putExtra("loginType", "Login");
				}else{
					intent.putExtra("loginType", "NotLogin");
				}
		        intent.putExtra("isSingleApp", "Y");
				startActivity(intent);
				finish();
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_GETBOOKMARK)){
			if(result != null){
				Log.e("getBookMarkData", result);
				String success=null;
				String lastPage=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
					JSONObject logData=responseLog.getJSONObject("logData");
					if(success.equals("5000")){
						//성공
//						Toast.makeText(MainActivity.this, "겟 북마크 페이지 로그데이터 전송 성공.", Toast.LENGTH_LONG).show();
						//DB 저장
						//json 변환
							
						if(logData.has("data")){
							Log.e("bookMark", "getdata");
							String data = logData.getString("data");
							Log.e("bookMarkLogData", data);
							if(!data.equals("")){
								//bookMarkTable 삭제
								dbHelper.deleteBookMarkTable(mDB);
								String dataJson=data.replaceAll("'\'","");
								Log.e("dataJason", dataJson);
								JSONObject jsonData = new JSONObject(dataJson);
								JSONArray bookMarks = jsonData.getJSONArray("bookmarks");
								for(int i=0; i<bookMarks.length();i++){
									JSONObject bookMarksitem = bookMarks.getJSONObject(i);
									BookMarkData bookData = new BookMarkData();
									if(bookMarksitem.has("contentsName")){
										bookData.setContentsName(bookMarksitem.getString("contentsName"));
									}
										
									if(bookMarksitem.has("_pageNo")){
										bookData.set_pageNo(Integer.parseInt(bookMarksitem.getString("_pageNo")));
									}
										
									if(bookMarksitem.has("thumbnailImageName")){
										bookData.setThumbnailImageName(bookMarksitem.getString("thumbnailImageName"));
									}
										
									if(bookMarksitem.has("time")){
										bookData.setTime(bookMarksitem.getString("time"));
									}
										
									boolean results=dbHelper.insertBookMarkData(mDB, bookData);
										
									if(results){
										Log.e("insertOk", "bookMarkInsertOk");
									}else{
										Log.e("insertFail", "bookMarkInsertFail");
									}
								}
							}
						}
						mHandler.sendEmptyMessage(REQUEST_COMPLETE);
					}	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				mHandler.sendEmptyMessage(REQUEST_COMPLETE);
			}
		}
	}
	
//	public void setMsgDialog(String msg){
//		AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
//		builder.setTitle("우아아아아아아아아아아")
//		.setMessage(msg)
//		.setCancelable(false)
//		.setPositiveButton(MainActivity.this.getString(R.string.ok), new DialogInterface.OnClickListener() {
//			
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//			}
//		})
//		.setNegativeButton(MainActivity.this.getString(R.string.cancel),new DialogInterface.OnClickListener() {
//			
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//			}
//		});
//		AlertDialog dialog = builder.create();
//		if(!dialog.isShowing()){
//			dialog.show();
//		}
//	}
	
	
	
}
