package com.example.module;

import java.util.ArrayList;

import android.database.Cursor;

public class BookMarkData {
	private String contentsName;
	private int _pageNo;
	private String thumbnailImageName;
	private String time;
	
	public BookMarkData() {
	}

	public String getContentsName() {
		return contentsName;
	}

	public void setContentsName(String contentsName) {
		this.contentsName = contentsName;
	}

	public int get_pageNo() {
		return _pageNo;
	}

	public void set_pageNo(int _pageNo) {
		this._pageNo = _pageNo;
	}

	public String getThumbnailImageName() {
		return thumbnailImageName;
	}

	public void setThumbnailImageName(String thumbnailImageName) {
		this.thumbnailImageName = thumbnailImageName;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
	
	public static ArrayList<BookMarkData> getDBookMarkInfo(Cursor cursor){
		
		int contentsNameIndex = cursor.getColumnIndex("contentsName");
		int _pageNoIndex = cursor.getColumnIndex("_pageNo");
		int thumbnailImageNameIndex = cursor.getColumnIndex("thumbnailImageName");
		int timeIndex = cursor.getColumnIndex("time");
		
		ArrayList<BookMarkData> array = new ArrayList<BookMarkData>();
		
		while (cursor.moveToNext()) {
			BookMarkData info = new BookMarkData();
			
			info.contentsName = cursor.getString(contentsNameIndex);
			info._pageNo = cursor.getInt(_pageNoIndex);
			info.thumbnailImageName = cursor.getString(thumbnailImageNameIndex);
			info.time = cursor.getString(timeIndex);
			
			array.add(info);
		}
		return array;
	}
}
