package com.example.custom;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.adapter.NotiAdapter;
import com.example.frgment.LoginFragment.OnStartActivityListener;
import com.example.stemplet1.R;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class CustomNotificationDialog extends Dialog implements android.view.View.OnClickListener{
	private Context mContex;
	private String notiResponse;
	private float resizeWith;
	private float resizeHeight;
	private ListView notiList;
	private TextView notiTextView;
	private Button OpenBtn;
	private Button CloseBtn;
	private NotiAdapter adapter;
	private JSONArray notiArray;
	private OnStartActivityListener mListener;
	private String inappSeq;
	private LinearLayout top_line;
	private LinearLayout title_line;
	private TextView number;
	private TextView title;
	private LinearLayout middle_line;
	private LinearLayout bottom_button_lnear;
	
	
	public CustomNotificationDialog(Context context, String notiResponse, OnStartActivityListener mListener ) {
		super(context);
		mContex = context;
		this.notiResponse = notiResponse;
		this.mListener = mListener;
		
		ArrayList<Float> deviceScaleArr=getDeviceScaling(mContex);
		resizeWith=deviceScaleArr.get(0);
		resizeHeight = deviceScaleArr.get(1);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.notification_dialog);
		
		notiList = (ListView)findViewById(R.id.notification_list);
		notiTextView = (TextView)findViewById(R.id.notification_description);

		OpenBtn = (Button)findViewById(R.id.open);
		OpenBtn.setVisibility(View.INVISIBLE);
		CloseBtn = (Button)findViewById(R.id.close);
		CloseBtn.setOnClickListener(this);
		
		top_line = (LinearLayout)findViewById(R.id.top_line);
		title_line = (LinearLayout)findViewById(R.id.titile_lienar);
		number = (TextView)findViewById(R.id.number);
		title = (TextView)findViewById(R.id.title);
		middle_line = (LinearLayout)findViewById(R.id.middle_line);
		bottom_button_lnear = (LinearLayout)findViewById(R.id.bottom_button_linear);
		
		//레이아웃
		LinearLayout.LayoutParams top_line_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*4));
		top_line_params.setMargins(Math.round(resizeWith*30), Math.round(resizeWith*36), Math.round(resizeWith*30), 0);
		top_line.setLayoutParams(top_line_params);
		
		LinearLayout.LayoutParams title_line_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*66));
		title_line_params.setMargins(Math.round(resizeWith*30), 0, Math.round(resizeWith*30), 0);
		title_line.setLayoutParams(title_line_params);
		
		LinearLayout.LayoutParams number_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
		number_params.setMargins(Math.round(resizeWith*30), 0, 0, 0);
		number.setLayoutParams(number_params);
		number.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeWith*25));
		number.setGravity(Gravity.CENTER);
		
		LinearLayout.LayoutParams title_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
		title_params.setMargins(Math.round(resizeWith*254), 0, 0, 0);
		title.setLayoutParams(title_params);
		title.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeWith*25));
		title.setGravity(Gravity.CENTER);
		
		LinearLayout.LayoutParams middle_line_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*2));
		middle_line_params.setMargins(Math.round(resizeWith*30), 0, Math.round(resizeWith*30), 0);
		middle_line.setLayoutParams(middle_line_params);
		
		LinearLayout.LayoutParams notilist_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*444));
		notilist_params.setMargins(Math.round(resizeWith*30), 0, Math.round(resizeWith*30), 0);
		notiList.setLayoutParams(notilist_params);
		
		LinearLayout.LayoutParams notitext_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*560));
		notitext_params.setMargins(Math.round(resizeWith*30), 0, Math.round(resizeWith*30),0);
		notiTextView.setLayoutParams(notitext_params);
		notiTextView.setPadding(Math.round(resizeWith*30), Math.round(resizeWith*30), 0, 0);
		notiTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeWith*30));
		
		LinearLayout.LayoutParams bottom_button_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*122));
		bottom_button_lnear.setLayoutParams(bottom_button_params);
		
		LinearLayout.LayoutParams open_params = new LinearLayout.LayoutParams(Math.round(resizeWith*142), Math.round(resizeWith*50));
		open_params.setMargins(Math.round(resizeWith*190), Math.round(resizeWith*36), 0, 0);
		OpenBtn.setLayoutParams(open_params);
		
		LinearLayout.LayoutParams close_params = new LinearLayout.LayoutParams(Math.round(resizeWith*142), Math.round(resizeWith*50));
		close_params.setMargins(Math.round(resizeWith*74), Math.round(resizeWith*36), 0, 0);
		CloseBtn.setLayoutParams(open_params);
		
		JSONObject notiResponseJson;
		notiArray=null;
		try {
			notiResponseJson = new JSONObject(notiResponse);
			notiArray=notiResponseJson.getJSONArray("noticeList");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		adapter = new NotiAdapter(mContex, notiArray, notiTextView);
		notiList.setAdapter(adapter);
		
		notiList.setOnItemClickListener(itemClick);
				
	}
	
	public ArrayList<Float> getDeviceScaling(Context context){
		ArrayList<Float> deviceScaleArr = new ArrayList<Float>();
		ArrayList<Integer> deviceSizeArr = getDisplay(context);
		int deviceWidth = deviceSizeArr.get(0);
		int deviceHeight = deviceSizeArr.get(1);
		
		float deviceScaleWidth = deviceWidth/800.0f;
		float deviceScaleHeight = deviceHeight/1280.0f;
		
		deviceScaleArr.add(deviceScaleWidth);
		deviceScaleArr.add(deviceScaleHeight);
		
		return deviceScaleArr;
	}
	
	public  ArrayList<Integer> getDisplay(Context context){
		Display dis = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		int mDisWith = dis.getWidth();
		int mDisHeight = dis.getHeight();	
		ArrayList<Integer>displayArr = new ArrayList<Integer>();
		displayArr.add(mDisWith);
		displayArr.add(mDisHeight);
		return displayArr;
	}
	
	public void setScaling(View v){
		v.setPivotX(0);
		v.setPivotY(0);
		v.setScaleX(resizeWith);
		v.setScaleY(resizeHeight);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.close:
			mListener.goMainActivity(false);
			break;
		default:
			break;
		}
	}
	
	OnItemClickListener itemClick = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int postion,
				long arg3) {
					String noticeText =null;
					inappSeq = null;
					try {
						JSONObject notiItem = notiArray.getJSONObject(postion);
						noticeText = notiItem.getString("noticeText");
						inappSeq = notiItem.getString("inappSeq");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					notiTextView.setText(noticeText);
				}
	};

}
