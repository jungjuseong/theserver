package com.example.adapter;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.stemplet1.R;

import android.content.Context;
import android.content.Context;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NotiAdapter extends BaseAdapter{
	private LayoutInflater inflater;
	private Context mContext;
	private JSONArray notiArray;
	private TextView notiTextView;
	private float resizeWith;
	private float resizeHeight;
	
	public NotiAdapter(Context context, JSONArray notiArray, TextView textView) {
		inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.mContext = context;
		this.notiArray = notiArray;
		this.notiTextView = textView;
		
		ArrayList<Float> deviceScaleArr=getDeviceScaling(mContext);
		resizeWith=deviceScaleArr.get(0);
		resizeHeight = deviceScaleArr.get(1);
	}
	
	@Override
	public int getCount() {
		if(notiArray == null){
			return 0;
		}else{
			return notiArray.length();
		}
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView == null){
			convertView = inflater.inflate(R.layout.notilist_item, parent, false);
		}
		
		LinearLayout notiadapter_line = (LinearLayout)convertView.findViewById(R.id.notiadapter_line);
		TextView noti_number_text = (TextView)convertView.findViewById(R.id.noti_number);
		TextView noti_list_text = (TextView) convertView.findViewById(R.id.noti_text);
		
		AbsListView.LayoutParams notiadapter_line_params = new AbsListView.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeWith*74));
		notiadapter_line.setLayoutParams(notiadapter_line_params);
		
		LinearLayout.LayoutParams noti_number_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
		noti_number_params.setMargins(Math.round(resizeWith*32), 0, 0, 0);
		noti_number_text.setLayoutParams(noti_number_params);
		noti_number_text.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeWith*30));
		noti_number_text.setGravity(Gravity.CENTER);
		
		LinearLayout.LayoutParams noti_list_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		noti_list_params.setMargins(Math.round(resizeWith*30), 0, 0, 0);
		noti_list_text.setLayoutParams(noti_list_params);
		noti_list_text.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeWith*30));
		noti_list_text.setGravity(Gravity.CENTER);
		
		noti_number_text.setText(String.valueOf(position+1));
		
		final JSONObject notiItem;
		try {
			notiItem = notiArray.getJSONObject(position);
			String notiName=notiItem.getString("noticeName");
			noti_list_text.setText(notiName);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return convertView;
	}
	
	public ArrayList<Float> getDeviceScaling(Context context){
		ArrayList<Float> deviceScaleArr = new ArrayList<Float>();
		ArrayList<Integer> deviceSizeArr = getDisplay(context);
		int deviceWidth = deviceSizeArr.get(0);
		int deviceHeight = deviceSizeArr.get(1);
		
		float deviceScaleWidth = deviceWidth/800.0f;
		float deviceScaleHeight = deviceHeight/1280.0f;
		
		deviceScaleArr.add(deviceScaleWidth);
		deviceScaleArr.add(deviceScaleHeight);
		
		return deviceScaleArr;
	}
	
	public  ArrayList<Integer> getDisplay(Context context){
		Display dis = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		int mDisWith = dis.getWidth();
		int mDisHeight = dis.getHeight();	
		ArrayList<Integer>displayArr = new ArrayList<Integer>();
		displayArr.add(mDisWith);
		displayArr.add(mDisHeight);
		return displayArr;
	}

}
