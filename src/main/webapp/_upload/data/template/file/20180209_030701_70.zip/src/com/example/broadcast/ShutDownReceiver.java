package com.example.broadcast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.clbee.authorviewer.PageActivity;
import com.example.constants.Constants;
import com.example.stemplet1.LoginActivity;
import com.example.stemplet1.R;
import com.example.util.SharedPreferenceManager;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.format.DateFormat;
import android.util.Log;

public class ShutDownReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		String IntentAction = intent.getAction();
		if(IntentAction.equals(Intent.ACTION_SCREEN_ON)){
			Log.e("receiver", "screen on");
			//현재시간 가져오기
			String current_time = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
			//저장된 시간 가져오기
			String save_time=SharedPreferenceManager.getSharedPreferences(Constants.BROADCAST_CURRENT_TIME, "");
			//dateformat 변경 
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			long duration = -1;
			try {
				Date startDate = dateFormat.parse(save_time);
				Date endDate = dateFormat.parse(current_time);
				duration = endDate.getTime() - startDate.getTime();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(duration != -1){
				//duration second 변환
				long duration_second = duration/1000;
				Log.e("duration_time", String.valueOf(duration_second));
				String login_second_time = context.getString(R.string.login_second_time); 
				if(login_second_time.equals("secondTime")){
					//미설정
					Log.e("aaaaa", "미설정");
				}else{
					//설정
					long loginSecondTime = Long.parseLong(login_second_time);
					if(loginSecondTime < duration_second){
						//로그인화면이동
						Log.e("aaaaa", "goLogin");
						Intent login_intent = new Intent(context.getPackageName());
						login_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						context.startActivity(login_intent);
						try{
							PageActivity pageActivity = (PageActivity)PageActivity.pageActivity;
							pageActivity.finish();
						}catch(Exception e){
							e.printStackTrace();
						}
					}else{
						//뷰어이동
					}
				}
			}
		}else if(IntentAction.equals(Intent.ACTION_USER_PRESENT)){
			Log.e("receiver", "user present");
			//현재시간 가져오기
			String current_time = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
			//저장된 시간 가져오기
			String save_time=SharedPreferenceManager.getSharedPreferences(Constants.BROADCAST_CURRENT_TIME, "");
			//dateformat 변경 
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			long duration = -1;
			try {
				Date startDate = dateFormat.parse(save_time);
				Date endDate = dateFormat.parse(current_time);
				duration = endDate.getTime() - startDate.getTime();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(duration != -1){
				//duration second 변환
				long duration_second = duration/1000;
				Log.e("duration_time", String.valueOf(duration_second));
				String login_second_time = context.getString(R.string.login_second_time); 
				if(login_second_time.equals("secondTime")){
					//미설정
					Log.e("aaaaa", "미설정");
				}else{
					//설정
					long loginSecondTime = Long.parseLong(login_second_time);
					if(loginSecondTime < duration_second){
						//로그인화면이동
						Log.e("aaaaa", "goLogin");
						Intent login_intent = new Intent(context.getPackageName());
						login_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						context.startActivity(login_intent);
						PageActivity pageActivity = (PageActivity)PageActivity.pageActivity;
						pageActivity.finish();
					}else{
						//뷰어이동
					}
				}
			}
		}else if(IntentAction.equals(Intent.ACTION_SCREEN_OFF)){
			Log.e("receiver", "screen off");
			//현재시간 가져오기
			String time=new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date(System.currentTimeMillis()));
			//현재시간 xml에 저장
			SharedPreferenceManager.putSharedPreferences(Constants.BROADCAST_CURRENT_TIME, time);
		}
	}

}
