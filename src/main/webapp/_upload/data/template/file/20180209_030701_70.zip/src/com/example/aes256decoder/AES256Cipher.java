package com.example.aes256decoder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.http.util.ByteArrayBuffer;

import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.constant.PageViewerConstant;
import com.example.constants.Constants;

import android.util.Log;

public class AES256Cipher {

	private static boolean isDecodeAble = false;

	public static byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

	public static int decodeByteLenth;

	public static byte[] AES_Encode(byte[] jsonByte, String key) throws java.io.UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		byte[] fileBytes = null;
//		try {
			fileBytes = jsonByte;
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		ivBytes = null;
		byte[] keyByte = key.getBytes("UTF-8");
		byte[] totalByte = new byte[32];
		System.arraycopy(keyByte, 0, totalByte, 0, keyByte.length);
		SecretKeySpec newKey = new SecretKeySpec(totalByte, "AES");
		Cipher cipher = null;
		cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
//		cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);

		return cipher.doFinal(fileBytes);
	}
	
	public static Object JNI_AES_Decode(String filePath, String key) {
		byte[] finalByte = AES_Decode(filePath);
		Object object = null;
		try {
			ByteArrayInputStream in = new ByteArrayInputStream(finalByte);
			ObjectInputStream is = new ObjectInputStream(in);

			// ByteArrayBuffer bf = new ByteArrayBuffer(finalByte.length);
			// bf.append(finalByte, 0, finalByte.length);
			// MyLog.e("bf length", bf.length()+"");
			// byte[] b = bf.toByteArray();
			// MyLog.e("bf1,2", b[0]+"//"+b[1]);
			object = is.readObject();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return object;
	}

	public static byte[] AES_Decode(String filePath) {
		String key = Constants.JSON_ENCODE_KEY;
		if ((key == null) || (key != null && key.equals(""))) {
			isDecodeAble = false;
		}else{
			isDecodeAble = true;
		}
		// try {
		// filePath = URLEncoder.encode(filePath, "utf-8");
		// } catch (UnsupportedEncodingException e1) {
		// MyLog.e("utf-8 EncodeError",
		// "utf-8 not Encode!!=>"+e1.getStackTrace());
		// }
		File file = new File(filePath);
		byte[] fileBytes = null;
		Cipher cipher = null;
		try {
			decodeByteLenth = -1;
			fileBytes = getBytesFromFile(file);
			if (isDecodeAble) {
				AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);

				byte[] keyByte = key.getBytes("UTF-8");
				byte[] totalByte = new byte[32];
				System.arraycopy(keyByte, 0, totalByte, 0, keyByte.length);
				SecretKeySpec newKey = new SecretKeySpec(totalByte, "AES");
				cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
				cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);

				byte[] finalByte = cipher.doFinal(fileBytes);
				decodeByteLenth = finalByte.length;
				keyByte = null;
				totalByte = null;
				fileBytes = null;

				return finalByte;
			} else {
				return fileBytes;
			}
		} catch (InvalidKeyException e) {
			// MyLog.e("AES_Decode:InvalidKeyException",
			// Log.getStackTraceString(e));
		} catch (UnsupportedEncodingException e) {
			// MyLog.e("AES_Decode:UnsupportedEncodingException",
			// Log.getStackTraceString(e));
		} catch (NoSuchAlgorithmException e) {
			// MyLog.e("AES_Decode:InvalidKeyException",
			// Log.getStackTraceString(e));
		} catch (NoSuchPaddingException e) {
			// MyLog.e("AES_Decode:NoSuchAlgorithmException",
			// Log.getStackTraceString(e));
		} catch (InvalidAlgorithmParameterException e) {
			// MyLog.e("AES_Decode:InvalidAlgorithmParameterException",
			// Log.getStackTraceString(e));
		} catch (IllegalBlockSizeException e) {
			// MyLog.e("AES_Decode:IllegalBlockSizeException",
			// Log.getStackTraceString(e));
		} catch (BadPaddingException e) {
			// // MyLog.e("AES_Decode:BadPaddingException",
			// Log.getStackTraceString(e));
		} catch (IOException e) {
			// MyLog.e("AES_Decode:IOException", Log.getStackTraceString(e));
		}
		return fileBytes;
	}
	
	public static byte[] AES_Decode(String filePath, String key, int viewText) {
		// try {
		// filePath = URLEncoder.encode(filePath, "utf-8");
		// } catch (UnsupportedEncodingException e1) {
		// MyLog.e("utf-8 EncodeError",
		// "utf-8 not Encode!!=>"+e1.getStackTrace());
		// }
		File file = new File(filePath);
		byte[] fileBytes = null;
		Cipher cipher = null;
		try {
			decodeByteLenth = -1;
			fileBytes = getBytesFromFile(file);
			if (true) {
				AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);

				byte[] keyByte = key.getBytes("UTF-8");
				byte[] totalByte = new byte[32];
				System.arraycopy(keyByte, 0, totalByte, 0, keyByte.length);
				SecretKeySpec newKey = new SecretKeySpec(totalByte, "AES");
				cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
				cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
				byte[] finalByte = cipher.doFinal(fileBytes);
			
				decodeByteLenth = finalByte.length;
				keyByte = null;
				totalByte = null;
				fileBytes = null;

				return finalByte;
			} else {
				return fileBytes;
			}
		} catch (InvalidKeyException e) {
			// MyLog.e("AES_Decode:InvalidKeyException",
			// Log.getStackTraceString(e));
		} catch (UnsupportedEncodingException e) {
			// MyLog.e("AES_Decode:UnsupportedEncodingException",
			// Log.getStackTraceString(e));
		} catch (NoSuchAlgorithmException e) {
			// MyLog.e("AES_Decode:InvalidKeyException",
			// Log.getStackTraceString(e));
		} catch (NoSuchPaddingException e) {
			// MyLog.e("AES_Decode:NoSuchAlgorithmException",
			// Log.getStackTraceString(e));
		} catch (InvalidAlgorithmParameterException e) {
			// MyLog.e("AES_Decode:InvalidAlgorithmParameterException",
			// Log.getStackTraceString(e));
		} catch (IllegalBlockSizeException e) {
			// MyLog.e("AES_Decode:IllegalBlockSizeException",
			// Log.getStackTraceString(e));
		} catch (BadPaddingException e) {
			// // MyLog.e("AES_Decode:BadPaddingException",
			// Log.getStackTraceString(e));
		} catch (IOException e) {
			// MyLog.e("AES_Decode:IOException", Log.getStackTraceString(e));
		}
		return fileBytes;
	}

	public static int getDecodeByteLenth(String filePath) {
		return decodeByteLenth;
	}

	public static byte[] getBytesFromFile(File file) throws IOException {
		
		 FileInputStream f = new FileInputStream(file);
		 FileChannel ch = f.getChannel( );		 
		 MappedByteBuffer mb = ch.map(MapMode.READ_ONLY,0L, ch.size( ) );
		 byte[] barray = new byte[Math.round(file.length())];
		 long checkSum = 0L;
		 int nGet;
		 while( mb.hasRemaining( ) )
		 {
		     nGet = Math.min( mb.remaining( ), Math.round(file.length()) );
		     mb.get( barray, 0, nGet );
		     for ( int i=0; i<nGet; i++ )
		     checkSum += barray[i];
		 }		
		return barray;
		
//		InputStream is = new FileInputStream(file);
//		long length = file.length();
//		if (length > Integer.MAX_VALUE) {
//			// File is too large
//		}
//
//		// Create the byte array to hold the data
//		byte[] bytes = new byte[(int) length];
//
//		// Read in the bytes
//		int offset = 0;
//		int numRead = 0;
//		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
//			offset += numRead;
//		}
//
//		// Ensure all the bytes have been read in
//		if (offset < bytes.length) {
//			throw new IOException("Could not completely read file " + file.getName());
//		}
//
//		// Close the input stream and return bytes
//		is.close();
//		return bytes;
	}
}