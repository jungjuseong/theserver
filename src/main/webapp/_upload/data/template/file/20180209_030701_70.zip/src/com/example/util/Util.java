package com.example.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;


public class Util {
	private final static String TAG = "UTILS";
	
	//네트워크 체크
	public static boolean isNetworkConnect(Context context){
		ConnectivityManager cm = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		
		if(mobile !=null && mobile.isConnected() || wifi.isConnected()){
			return true;
		} else {
			return false;
		}
	}
	
	//jsonFile txt 로 쓰기
		public static void FileWrite(String path, String startTime){
			
			File save_jsonFile = new File(path);
			try {
				FileOutputStream fos = new FileOutputStream(save_jsonFile);
				fos.write(startTime.getBytes());
				fos.close();
				Log.d(TAG, "json_File_write_complete");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//txt jsonFile 읽어오기
		public static String FileRead(String path){
			File readJsonFile = new File(path);
			String file_response = null;
			String strTxt="";
			if(readJsonFile.exists()){
				try {
					BufferedReader buf = new BufferedReader(new FileReader(readJsonFile));
					while ((file_response = buf.readLine()) != null) {
						strTxt+=file_response;
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return strTxt = "";
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return strTxt;
		}
		
		//jsonFile txt 로 쓰기
		public static void JsonFileWrite(String path, String json_response){
			
			File save_jsonFile = new File(path);
			try {
				FileOutputStream fos = new FileOutputStream(save_jsonFile);
				fos.write(json_response.getBytes());
				fos.close();
				Log.d(TAG, "json_File_write_complete");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//txt jsonFile 읽어오기
		public static String JsonFileRead(String path){
			File readJsonFile = new File(path);
			String file_response = null;
			String strTxt="";
			if(readJsonFile.exists()){
				try {
					BufferedReader buf = new BufferedReader(new FileReader(readJsonFile));
					while ((file_response = buf.readLine()) != null) {
						strTxt+=file_response;
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return strTxt;
		}
		
}
