package com.example.http;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.widget.Toast;

import com.squareup.okhttp.FormEncodingBuilder;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by KiOhJeong on 15. 9. 7..
 */
public class PostHTTPAsync extends AsyncTask {
    private Fragment mFragment;
    private OnPostExecuteListener mListener;
    private String mReqURL;
    private String mProcessID;
    private Activity mActivity;
    private BroadcastReceiver mReceiver;
    private Context mContext;
    private int mResponseCode;
    
    public PostHTTPAsync(Fragment fragment, String reqURL, String processID, Context context) {
        mListener = (OnPostExecuteListener) fragment;
        mReqURL = reqURL;
        mProcessID = processID;
        mContext = context;
    }
    
    public PostHTTPAsync(Activity activity, String reqURL, String processID, Context context) {
		// TODO Auto-generated constructor stub
    	mActivity = activity;  
    	mListener = (OnPostExecuteListener) activity;
        mReqURL = reqURL;
        mProcessID = processID;
        mContext = context;
	}
    
    public PostHTTPAsync(BroadcastReceiver reciever,Context context,String reqURL, String processID) {
 		// TODO Auto-generated constructor stub
    	mReceiver = reciever; 
    	mContext = context;
     	mListener = (OnPostExecuteListener) reciever;
        mReqURL = reqURL;
        mProcessID = processID;
 	}
    
    @Override
    protected Object doInBackground(Object[] params) {
        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(3, TimeUnit.SECONDS);
        MediaType JSON = MediaType.parse("application/text; charset=utf-8");
        FormEncodingBuilder feb = new FormEncodingBuilder();

        if (params[0] != null) {
            HashMap<String, String> requestInfo = (HashMap) params[0];
            String[] keys = requestInfo.keySet().toArray(new String[0]);
            for (int i = 0; i < keys.length; i++) {
                String key = keys[i];
                feb.add(key, requestInfo.get(key));
            }
        }
        RequestBody formBody = feb.build();
        Request request = new Request.Builder().url(mReqURL).post(formBody).build();
        Response response = null;
        try {
        	 ConnectivityManager manager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
             NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
             NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
             
             // wifi 또는 모바일 네트워크 어느 하나라도 연결이 되어있다면,
             if (wifi.isConnected() || mobile.isConnected()) {
            	 response = client.newCall(request).execute();
                 mResponseCode = response.code(); 
             }else{
            	 return null;
             }  
        }catch (SocketTimeoutException e){
        	e.printStackTrace();
        	return "TimeOut";    
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        String resBody = null;
        try {
            resBody = response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return resBody;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        if (mResponseCode == 200) {
       	 ConnectivityManager manager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

            // wifi 또는 모바일 네트워크 어느 하나라도 연결이 되어있다면,
            if ((wifi != null  && wifi.isConnected()) || (mobile != null && mobile.isConnected())) {
           	 boolean isError = false;
          	  try {
                    JSONObject jo = new JSONObject((String) o);
                } catch (JSONException e) {
                    try {
                        JSONArray jo = new JSONArray((String) o);
                    } catch (JSONException ee) {
                        isError = true;
                        if (((String) o).equalsIgnoreCase("true")||((String) o).equalsIgnoreCase("true")) {
                            isError = false;
                        }else{
                            isError = true;
                        }
                        e.printStackTrace();

                    }
                }
          	   if (!isError) {
                     if (mListener != null) {
                         if (o != null) {
                             mListener.onJsonPostExcute(mProcessID, (String) o);
                         } else {
                      	   mListener.onJsonPostExcute(mProcessID, (String) o);
                         }
                     } else {
                  	   if(mActivity != null){
                  		   Toast.makeText(mActivity, "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                         }else if(mContext != null){
                        	 Toast.makeText(mContext, "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                         }else{
                        	 Toast.makeText(mFragment.getActivity(), "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                         }
                     }
                 } else {
              	   if(mActivity != null){
                 		 Toast.makeText(mActivity, "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                 	   }else if(mContext != null){
                 		 Toast.makeText(mContext, "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                 	   }else{
                 		 Toast.makeText(mFragment.getActivity(), "must implement OnPostExecuteListener", Toast.LENGTH_LONG).show();
                 	   }
                 } 
            }else{
            	mListener.onJsonPostExcute(mProcessID, null);   
            }
       }else{
    	   mListener.onJsonPostExcute(mProcessID, null);   
       }
    }

    public interface OnPostExecuteListener {
        // TODO: Update argument type and name
        public void onJsonPostExcute(String processID, String result);
    }
}
