package com.example.constants;

import java.io.File;

import android.os.Environment;

public class Constants {
	public static final String SD_CARD_PATH =Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator;
	
	//network
	public static final int ERROR_CODE_NETWORK_DISCONNECT = 500;
	public static final int ERROR_CODE_USER_CANCEL = -2;
	public static final int ERROR_CODE_UNKNOWN = -1;
	
	public static final int HTTP_CONN_TIMEOUT = 30 * 1000;
	public static final int HTTP_READ_TIMEOUT = 30 * 1000;
	
	public static final String HTTP_POST ="POST";
	public static final String HTTP_GET = "GET";

	
   // 테스트 모드일 때 URL fantec	
//	public static final String URL_LOG_IN =  "http://210.155.152.246:8080/loginVerify.html";
//	public static final String COMPANY_ID =  "me_partner_01";
//	public static final String URL_CONTENTS_DOWN =  "http://210.155.152.246:8080/_upload/data/app/contents";

	//테스트 모드일 때 URL 190번 서버
	public static  String URL_LOG_IN =  "http://211.218.206.150:8080/loginVerify.html";
	public static  String COMPANY_ID =  "ClbeeSystem";
	public static  String URL_CONTENTS_DOWN =  "http://221.143.22.213:8080/newcms/data/app/contents";
	
//    <string name="login_url">http://211.218.206.150:8080/loginVerify.html</string>
//    <string name="login_company_id">ClbeeSystem</string>
//    <string name="contents_down_url">http://221.143.22.213:8080/newcms/data/app/contents</string>
//	<string name="login_second_time">300</string>
//	<string name="logout_second_time">300</string>
	
	
	//json_encoder_key
	public static final String JSON_ENCODE_KEY = "NextStep93";
	
	//AndroidFolder
	public static final String ANDROID_FOLDER = Environment.getExternalStorageDirectory().getAbsolutePath()
			+File.separator+"Android"+File.separator;
	
	public static final String ENCODE_FILE_NAME = "json_encod_file";

	//broadcastTime
	public static final String BROADCAST_CURRENT_TIME = "broad_current_time";
	//count
	public static final String LOGIN_COUNT = "count";
	
	//data base name
	public static final String DATABASE_NAME="bookshelf_db";
	public static final int DATABASE_VERSION =1;
	
	public static final String LOGINSTATE = "loginState";
	public static final String LOGIN = "Login";
	public static final String NOTLOGIN = "NotLogin";
	
	public static final String DEVICE_NUMBER = "deviceNumber";
	public static final String NOTNETWORKSTART_TIMES = "notNetWorkStartTime";
	public static final String USER_SQ = "userSeq";
	
	public static final String COMPANY_SQ = "companySeq";
	public static final String LOGIN_JSON = "loginJson";
	//file_path
	public static final String CONTENT_DOWNLOAD_FOLER = Environment.getExternalStorageDirectory().getAbsolutePath()
														+File.separator+"Android"+File.separator;
	
	public static final String LAST_LOGIN_DATA ="lastLoginData";
	public static final String LAST_LOGIN_PASS = "lastLoginPass";
	
	public static final String APP_VIEW_STATUS ="status";
	
	public static final String TEST_BUNDLE_ID = "com.clbee.testddd";
	
	public static final String REQUEST_PROCESS_ID_LOGIN = "REQUEST_LOGIN";
	public static final String REQUEST_PROCESS_ID_LOGINDATA = "REQUEST_LOGIN_DATA";
	public static final String REQUEST_PROCESS_ID_DEVICEDATA = "REQUEST_DEVICE_DATA";
	public static final String REQUEST_PROCESS_ID_NOTLASTPAGE = "REQUEST_NOTLAST_DATA";
	public static final String REQUEST_PROCESS_ID_NOTBOOKMARKDATA = "REQUEST_NOTBOOKMARK_DATA";
	public static final String REQUEST_PROCESS_ID_NOTSERVERDATA = "REQUEST_NOTSERVER_DATA";
	public static final String REQUEST_PROCESS_ID_DEVIDELOGIN = "REQUEST_DEVIDELOGIN_DATA";
	public static final String REQUEST_PROCESS_ID_LASTPAGE = "REQUEST_LASTPAGE";
	public static final String REQUEST_PROCESS_ID_BOOKMARK = "REQUEST_BOOKMARK";
	public static final String REQUEST_PROCESS_ID_CATEGORY = "REQUEST_CATEGORY";
	public static final String REQUEST_PROCESS_ID_NOTIFICATION = "REQUEST_NOTIFICATION";
	public static final String REQUEST_PROCESS_ID_LOGOUT = "REQUEST_LOGOUT";
	public static final String REQUEST_PROCESS_ID_SERVERDATA = "REQUEST_SERVERDATA";
	public static final String REQUEST_PROCESS_ID_GETLASTPAGE = "REQUEST_GETLASTPAGE";
	public static final String REQUEST_PROCESS_ID_GETBOOKMARK = "REQUEST_GETBOOKMARK";
}