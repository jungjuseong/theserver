package com.example.stemplet1;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.io.RandomAccessFile;
import java.io.ObjectInputStream.GetField;
import java.text.DecimalFormat;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.kutil.KUtil;
import com.example.constants.Constants;
import com.example.stemplet1.R;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StatFs;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

public class FileDownLoader2 {
	private Context mContext;
	private DefaultHttpClient httpClient;
	private int fileSize = 0;
	private ProgressDialog progressDialog;
	private String url;
	private AlertDialog.Builder mSelectScardDialog;

	private Handler progressHandler;
	private Toast mToast;
	private final int FILESIZE_CHECK_OK = 10;
	private final int DOWNLOAD_OK = 11;
	private final int DOWNFILE_EXISTS = 12;
	private final int NETWORK_ERROR = 13;
	
	public FileDownLoader2(Context context) {
		mContext = context;

		// String bundle_id = Constants.TEST_BUNDLE_ID;
		String values_url = Constants.URL_CONTENTS_DOWN;
		if (values_url.endsWith("/")) {
			url = Constants.URL_CONTENTS_DOWN + mContext.getPackageName() + "/contents.zip";
		} else {
			url = Constants.URL_CONTENTS_DOWN + File.separator + mContext.getPackageName() + "/contents.zip";
		}
		progressHandler = new Handler() {
			public void handleMessage(android.os.Message msg) {
				switch (msg.what) {
				case FILESIZE_CHECK_OK:
					mSelectScardDialog = new AlertDialog.Builder(mContext);
					File[] dirs = ContextCompat.getExternalFilesDirs(mContext, null);
					if (dirs !=null && dirs.length > 1  && dirs[1] != null) { // 삽입된 외장 sdcard가 있을경우.
						File path = dirs[1];
						StatFs stat = new StatFs(path.getPath());
						final long blockSize = stat.getBlockSize();
						final long availableBlocks = stat.getAvailableBlocks();
						mSelectScardDialog.setMessage("Contents(" + getFileSize(fileSize) + ")를 다운로드 합니다.\n어디에 저장하시겠습니까?\n 남은 공간 - 기본 : "
								+ getFileSize(Environment.getExternalStorageDirectory().getUsableSpace()) + "/SD Card : " + getFileSize(availableBlocks * blockSize));
						mSelectScardDialog.setPositiveButton("기본 저장소", new OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								if (Environment.getExternalStorageDirectory().getUsableSpace() < fileSize) {
									Toast.makeText(mContext, "저장소 용량이 부족합니다. 확인 후 다시 시도해 주세요.", Toast.LENGTH_LONG).show();
								} else {
									KUtil.saveString(mContext, "isSDCard", "false");
									download(url, false);
								}
							}
						});
						mSelectScardDialog.setNeutralButton("SD Card", new OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
							
								if (availableBlocks * blockSize < fileSize) {
									Toast.makeText(mContext, "저장소 용량이 부족합니다. 확인 후 다시 시도해 주세요.", Toast.LENGTH_LONG).show();
								} else {
								   KUtil.saveString(mContext, "isSDCard", "true");
									download(url, true);
								}
							}
						});
						mSelectScardDialog.setNegativeButton("취소", new OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								((MainActivity) mContext).finish();
							}
						});
						mSelectScardDialog.setCancelable(false);
						mSelectScardDialog.show();
						for (File dir : dirs) {
							Log.e("dir", dir.toString());

						}

					} else { // sdcard없는 경우.
						KUtil.saveString(mContext, "isSDCard", "false");
						download(url, false);
					}

					break;
				case DOWNLOAD_OK:
					if (progressDialog != null && progressDialog.isShowing()) {
						progressDialog.dismiss();
						progressDialog = null;
					}
					showMsg(mContext.getString(R.string.download_end));
					((MainActivity) mContext).mHandler.sendEmptyMessage(DOWNLOAD_OK);
					break;
				case NETWORK_ERROR:

					showMsg(mContext.getString(R.string.download_network_error));

					new Handler().postDelayed(new Runnable() {

						@Override
						public void run() {
							((MainActivity) mContext).finish();
						}
					}, 1500);

					break;
				}
			}
		};
		mToast = Toast.makeText(mContext, "", Toast.LENGTH_LONG);
		// setProgressDialog();
		new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					fileSize = getDownLoadSize(url);
					progressHandler.sendEmptyMessage(FILESIZE_CHECK_OK);

				} catch (ClientProtocolException e) {
					progressHandler.sendEmptyMessage(NETWORK_ERROR);
					e.printStackTrace();
				} catch (IOException e) {
					progressHandler.sendEmptyMessage(NETWORK_ERROR);
					e.printStackTrace();
				}

			}
		}).start();

	}

	public void download(final String url, final boolean isSDCard) {
		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {

				// setRunningState(true);
				File contentsFolder = null; 
						if (isSDCard) {
							File[] dirs = ContextCompat.getExternalFilesDirs(mContext, null);
							contentsFolder = new File(dirs[1].toString().replace("files", ""));
						}else{
						contentsFolder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + File.separator + "Android" + File.separator + "data" + File.separator
						+ mContext.getPackageName() + File.separator);
						}
				String localFileName = contentsFolder + File.separator + "contents.zip";

				if (new File(localFileName).exists()) {
					if (new File(localFileName).length() == fileSize) {
						((MainActivity) mContext).mHandler.sendEmptyMessage(DOWNFILE_EXISTS);
						return;
					}
				}

				InputStream in = null;

				RandomAccessFile raf = null;

				if (!contentsFolder.exists()) {
					contentsFolder.mkdirs();
				}

				try {

					long mStartByte = 0;

					if (new File(localFileName).exists()) {
						mStartByte = new File(localFileName).length();
					}

					String byteRange = mStartByte + "-" + fileSize;
					// conn.setRequestProperty("Range", "bytes=" + byteRange);

					startDownloadProgress();
					HttpGet httpPost = new HttpGet(url);
					httpPost.addHeader("Range", "bytes=" + byteRange);
					try {
						httpClient.getConnectionManager().shutdown();
					} catch (Exception e) {
						// TODO: handle exception
					}

					httpClient = getClient();

					HttpResponse response = httpClient.execute(httpPost);
					HttpEntity entity = response.getEntity();

					response = httpClient.execute(httpPost);

					entity = response.getEntity();

					in = entity.getContent();

					if ((fileSize - mStartByte) != entity.getContentLength()) {
						throw new IOException("not valid data");
					}

					raf = new RandomAccessFile(localFileName, "rw");
					raf.seek(mStartByte);

					byte data[] = new byte[2048];
					int numRead;

					notifiyProgressChange(mStartByte);
					while ((numRead = in.read(data)) != -1) {
						// out.write(buffer, 0, numRead);
						raf.write(data, 0, numRead);
						// notifiyProgressChange(numWritten);
						mStartByte += numRead;
						// Log.e("StartByte", mStartByte + "");
						notifiyProgressChange(mStartByte);

						// if (!isRunning) {
						// throw new
						// InterruptedIOException("Interrupted for user request.!!!");
						// }
					}

					if (in != null) {
						in.close();
					}

					progressHandler.sendEmptyMessage(DOWNLOAD_OK);

				} catch (InterruptedIOException e0) {
					progressHandler.sendEmptyMessage(NETWORK_ERROR);
				} catch (Exception exception) {
					progressHandler.sendEmptyMessage(NETWORK_ERROR);
					Log.e("FileWriteError", Log.getStackTraceString(exception));
					exception.printStackTrace();

				} finally {
					try {
						if (in != null) {
							in.close();

						}
					} catch (IOException ioe) {

					}
				}
			}
		});
		thread.setDaemon(true);
		thread.start();
	}

	private int getDownLoadSize(String url) throws ClientProtocolException, IOException {
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

			}
		}).start();
		long size = -1;
		try {
			httpClient = getClient();
			HttpGet httpPost = new HttpGet(url);
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();

			response = httpClient.execute(httpPost);

			entity = response.getEntity();

			size = entity.getContentLength();

		} catch (IllegalStateException e1) {
			// connectDataFailFinish();
		} catch (IOException e0) {
			e0.printStackTrace();
			// connectDataFailFinish();
		} finally {
		}

		return (int) size;
	}

	public DefaultHttpClient getClient() {
		DefaultHttpClient ret = null;

		// sets up parameters
		HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setContentCharset(params, "utf-8");
		params.setBooleanParameter("http.protocol.expect-continue", false);

		// registers schemes for both http and https
		SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
		// registry.register(new Scheme("https", new EasySSLSocketFactory2(),
		// 443));
		ThreadSafeClientConnManager manager = new ThreadSafeClientConnManager(params, registry);
		ret = new DefaultHttpClient(manager, params);

		return ret;
	}

	private void startDownloadProgress() {
		progressHandler.post(new Runnable() {

			@Override
			public void run() {
				if (progressDialog == null) {
					progressDialog = new ProgressDialog(mContext);
				}
				progressDialog.setCancelable(false);
				progressDialog.setMessage(mContext.getString(R.string.download_start));
				progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				progressDialog.setProgress(0);
				progressDialog.setMax(fileSize);
				// progressDialog.setButton("Ï∑®ÔøΩ??", new
				// DialogInterface.OnClickListener() {
				//
				// @Override
				// public void onClick(DialogInterface dialog, int which) {
				// showMsg("??ÔøΩÔøΩ?ÔøΩÔøΩ?????Ôø?? Ï∑®ÔøΩ???????? ??ÔøΩÔøΩ?? Ôø??Ôø?? ??ÔøΩÔøΩ?????.");
				// dialog.dismiss();
				// dialog = null;
				// ((MainActivity)mContext).finish();
				// }
				// });

				if (!progressDialog.isShowing()) {
					progressDialog.show();
				}
			}

		});
	}

	private void notifiyProgressChange(final long currentStt) {
		progressHandler.post(new Runnable() {

			@Override
			public void run() {
				progressDialog.setProgress((int) currentStt);
			}

		});
	}

	public void showMsg(final String msg) {
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				mToast.setText(msg);
				mToast.show();
			}

		}, 20);
	}

	public String getFileSize(long size) {
		if (size <= 0)
			return "0";
		final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
		int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
		return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
	}
}


