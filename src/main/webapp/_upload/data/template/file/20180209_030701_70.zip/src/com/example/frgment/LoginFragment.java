package com.example.frgment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.clbee.authorviewer.PageActivity;
import com.clbee.authorviewer.db.DBManager;
import com.clbee.authorviewer.kutil.KUtil;
import com.example.aes256decoder.AES256Cipher;
import com.example.constants.Constants;
import com.example.custom.CustomNotificationDialog;
import com.example.db.DataBaseHelper;
import com.example.http.HttpRequest;
import com.example.http.PostHTTPAsync;
import com.example.module.BookMarkData;
import com.example.stemplet1.R;
import com.example.util.SharedPreferenceManager;
import com.example.util.Util;
import com.kic.util.JsonUtil;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class LoginFragment extends Fragment implements PostHTTPAsync.OnPostExecuteListener{
	private Activity mActivity;
	private float resizeWith;
	private float resizeHeight;
	private TextView login_title;
	private EditText id_txt;
	private EditText pass_txt;
	private Button login_btn;
	private OnStartActivityListener mListener;
	private OnWriteAESFileListenter mWriteListener;
	private ProgressDialog progressDialog;
	private boolean login_state = false;
	private int not_network_count = 3;
	private String dialog_msg;
	private String userSeq;
	private DBManager mDbHelper;
	private SQLiteDatabase mDB;
	private SQLiteDatabase db;
	private DataBaseHelper dbHelper;
	private String loginresponse;
	
	public static LoginFragment newInstance(){
		LoginFragment fragment = new LoginFragment();
		return fragment;
	}
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		mActivity = activity;
		ArrayList<Float> deviceScaleArr=getDeviceScaling(getActivity());
		resizeWith=deviceScaleArr.get(0);
		resizeHeight = deviceScaleArr.get(1);
			
		try {
			mListener = (OnStartActivityListener) activity;
			mWriteListener = (OnWriteAESFileListenter) activity;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		dbHelper = new DataBaseHelper(getActivity());
		mDbHelper = new DBManager(getActivity());
		db = dbHelper.getWritableDatabase();
		mDB = mDbHelper.getWritableDatabase();
		dbHelper.onCreate(db);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.login_fragment, container, false);
		
		// view create
		login_title = (TextView)view.findViewById(R.id.login_title);
		id_txt = (EditText)view.findViewById(R.id.id_txt);
		pass_txt = (EditText)view.findViewById(R.id.pass_txt);
		login_btn = (Button)view.findViewById(R.id.login_btn);
		
		//textview
		LinearLayout.LayoutParams login_title_params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		login_title.setGravity(Gravity.CENTER);
		login_title.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeHeight*60));
		login_title_params.setMargins(0, Math.round(resizeWith*70), 0, 0);
		login_title.setLayoutParams(login_title_params);
				
		//id_txt layout
		LinearLayout.LayoutParams id_txt_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeHeight*90));
		id_txt_params.setMargins(Math.round(resizeWith*30), Math.round(resizeWith*115), Math.round(resizeWith*30), 0);
		id_txt.setPadding(Math.round(resizeWith*30), 0, 0, 0);
		id_txt.setLayoutParams(id_txt_params);
		
		id_txt.setOnEditorActionListener(onEditorActionListener);
		
		//pass_txt layout
		LinearLayout.LayoutParams pass_txt_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeHeight*90));
		pass_txt_params.setMargins(Math.round(resizeWith*30), Math.round(resizeHeight*40), Math.round(resizeWith*30), 0);
		pass_txt.setPadding(Math.round(resizeWith*30), 0, 0, 0);
		pass_txt.setLayoutParams(pass_txt_params);
		
		pass_txt.setOnEditorActionListener(onEditorActionListener);
		
		
		//login_btn layout
		//id_txt layout
		LinearLayout.LayoutParams login_btn_params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Math.round(resizeHeight*96));
		login_btn_params.setMargins(Math.round(resizeWith*30), Math.round(resizeHeight*53), Math.round(resizeWith*30), 0);
		login_btn.setLayoutParams(login_btn_params);
//		login_btn.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(resizeHeight*60));
		
		//setData
				//app_name 
				String app_name = null;
				try {
					app_name = (String)getActivity().getPackageManager().
							getApplicationLabel(getActivity().getPackageManager().getApplicationInfo(getActivity().getPackageName(), PackageManager.GET_UNINSTALLED_PACKAGES));
				} catch (NameNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				login_title.setText(app_name);
		
		login_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				loginHandler.sendEmptyMessage(1000);
			}
		});
		SharedPreferenceManager.putSharedPreferences(Constants.APP_VIEW_STATUS, Constants.LOGIN);
		return view;
	}
	
	public interface OnStartActivityListener{
		public void goMainActivity(boolean notNetwork);
	}
	
	public interface OnWriteAESFileListenter{
		public void writeAESFile(String response);
	}
	
	OnEditorActionListener onEditorActionListener = new TextView.OnEditorActionListener(){		
		@Override
		public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
			loginHandler.sendEmptyMessage(1000);
			return false;
		}
	};
	
	public Handler loginHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 1000:
//				mListener.goMainActivity();
				//httpRequest
				setProgressDialogShow(getActivity().getString(R.string.login_loging_msg));
				setRequestLogin();
				break;
			default:
				break;
			}
		}
	};
	
	String id;
	String pass;
	
	public void setRequestLogin(){
		String url = Constants.URL_LOG_IN;
		id = id_txt.getText().toString();
		pass = pass_txt.getText().toString();
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String deviceId = getDeviceNumber();
		Log.e("deviceID",deviceId);
		SharedPreferenceManager.putSharedPreferences(Constants.DEVICE_NUMBER, deviceId);
			
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("userId", id);
		params.put("userPw", pass);
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("ostype", "4");
			
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_LOGIN, getActivity());
		pj.execute(params);
	}

	
	public ArrayList<Float> getDeviceScaling(Context context){
		ArrayList<Float> deviceScaleArr = new ArrayList<Float>();
		ArrayList<Integer> deviceSizeArr = getDisplay(context);
		int deviceWidth = deviceSizeArr.get(0);
		int deviceHeight = deviceSizeArr.get(1);
		
		float deviceScaleWidth = deviceWidth/800.0f;
		float deviceScaleHeight = deviceHeight/1280.0f;
		
		deviceScaleArr.add(deviceScaleWidth);
		deviceScaleArr.add(deviceScaleHeight);
		
		return deviceScaleArr;
	}
	
	public  ArrayList<Integer> getDisplay(Context context){
		Display dis = ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		int mDisWith = dis.getWidth();
		int mDisHeight = dis.getHeight();	
		ArrayList<Integer>displayArr = new ArrayList<Integer>();
		displayArr.add(mDisWith);
		displayArr.add(mDisHeight);
		return displayArr;
	}
	
	public void setProgressDialogShow(String txt){
		if(progressDialog == null){
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(txt);
			progressDialog.setCancelable(false);
			progressDialog.show();
		}
	}
	
	public void setProgressDialogDismiss(){
		if(progressDialog != null && progressDialog.isShowing()){
			progressDialog.dismiss();
			progressDialog = null;
		}
	}
	
	public void AlertDialog(){
		android.app.AlertDialog.Builder ab=new AlertDialog.Builder(getActivity());
		ab.setMessage(dialog_msg);
		ab.setPositiveButton("ok", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		ab.show();
	}
	
	public String getDeviceNumber(){
		String android_id = android.provider.Settings.Secure.getString(getActivity().getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
		return android_id;
	}
	
	public void DeviceDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.logindeviceconnert))
		.setMessage(getActivity().getString(R.string.login_device_msg))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				//통신기기 등록
				setProgressDialogDismiss();
				setDeviceRequest();
			}
		})
		.setNegativeButton(getActivity().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void setDeviceRequest(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithAndroid.html");
		Log.e("url", url);
		String device_id = getDeviceNumber();
		String device_info = Build.MODEL;
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "2");
		params.put("deviceUuid", device_id);
		params.put("deviceInfo", device_info);
		params.put("deviceType", "Android");
		params.put("regUserSeq", userSeq);
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_LOGINDATA, getActivity());
		pj.execute(params);
	}
		
	public void setRequestLoginLogData(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String deviceId = SharedPreferenceManager.getSharedPreferences(Constants.DEVICE_NUMBER, "");
		String data = "login";
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "1");
		params.put("data", data);
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_LOGINDATA, getActivity());
		pj.execute(params);
	}
	
	public void setRequestNotifications(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String user_seq = SharedPreferenceManager.getSharedPreferences(Constants.USER_SQ, "");
		String companySeq = SharedPreferenceManager.getSharedPreferences(Constants.COMPANY_SQ, "");
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "17");
		params.put("companySeq", companySeq);
		params.put("storeBundleId", bundle_id);
		params.put("userSeq", user_seq);
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_NOTIFICATION, getActivity());
		pj.execute(params);
	}
		
	
	public String getCollectAnwer() throws Exception {
		String mFilePath = 	Constants.CONTENT_DOWNLOAD_FOLER+"data"+File.separator+getActivity().getPackageName()+File.separator+"contents"+File.separator;
		File dir = new File(mFilePath + "Answer");
		File[] fileList = dir.listFiles();
		String strCorrect = "";
		Arrays.sort(fileList);

		JSONObject jCollectAnswer = new JSONObject();

		for (int i = 0; i < fileList.length; i++) {
			if (!(fileList[i].getName().equals(".DS_Store"))) {
				JsonUtil jsonUtil = JsonUtil.getInstance();
				String strRead = jsonUtil.readStringFromSdCardFile(mFilePath + "Answer" + File.separator + fileList[i].getName());

				JSONObject jRead = new JSONObject(strRead);
				Iterator<String> keys = jRead.keys();
				while (keys.hasNext()) {
					String key = keys.next();
					JSONObject jObj = jRead.getJSONObject(key);
					try {
						if (jObj != null) {
							jCollectAnswer.put(key, jObj);
						}

					} catch (Exception e) {
						Log.e("jCollectAnswer", Log.getStackTraceString(e));
					}

				}

			}

		}
		JSONObject jResult = new JSONObject();
		jResult.put("Answer", jCollectAnswer);
		return jResult.toString();
	}
	
	public void setRequestNotNetworkLastPage(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String deviceId = getDeviceNumber();
		String lastJsonResponse = SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_DATA, "");
		String userSeq=null;
		try {
			JSONObject lastJson = new JSONObject(lastJsonResponse);
			userSeq=lastJson.getString("userSeq");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String pageGb = KUtil.currentPageFileRead(getActivity(), "contents");
		String data = "lastPage";
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("pageGb", pageGb);
		params.put("dataGb", "3");
		params.put("data", data);
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_NOTLASTPAGE, getActivity());
		pj.execute(params);
	}
	
	public void setRequestNotNetWorkBookMarkData(){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String deviceId =getDeviceNumber();
		String lastJsonResponse = SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_DATA, "");
		String userSeq=null;
		try {
			JSONObject lastJson = new JSONObject(lastJsonResponse);
			userSeq=lastJson.getString("userSeq");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<BookMarkData> bookMarkArr=dbHelper.getBookMark(mDB, "contents");
		JSONObject sendJson = new JSONObject();
		try {
		JSONArray array = new JSONArray();
			for(int i=0; i < bookMarkArr.size(); i++){
				BookMarkData data=bookMarkArr.get(i);
					JSONObject obj = new JSONObject();
					obj.put("contentsName", data.getContentsName());
					obj.put("_pageNo", data.get_pageNo());
					obj.put("thumbnailImageName", data.getThumbnailImageName());
					obj.put("time", data.getTime());
					array.put(obj);
				
			}
			sendJson.put("bookmarks", array);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "4");
		params.put("data", sendJson.toString());
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_NOTBOOKMARKDATA, getActivity());
		pj.execute(params);
	}
	
	public void setRequestNotNetworkSerVerResult(String data){
		String url = Constants.URL_LOG_IN;
		url = url.replace("loginVerify.html", "connectWithPageBuilder.html");
		Log.e("url", url);
		String bundle_id = getActivity().getPackageName();
//		String bundle_id = Constants.TEST_BUNDLE_ID;
		String deviceId = getDeviceNumber();
		Log.e("DEViceId", deviceId);
		String lastJsonResponse = SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_DATA, "");
		String userSeq=null;
		try {
			JSONObject lastJson = new JSONObject(lastJsonResponse);
			userSeq=lastJson.getString("userSeq");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("workPath", "14");
		params.put("deviceUuid", deviceId);
		params.put("storeBundleId", bundle_id);
		params.put("regUserSeq", userSeq);
		params.put("dataGb", "5");
		params.put("data", data);
		
		PostHTTPAsync pj = new PostHTTPAsync(LoginFragment.this, url, Constants.REQUEST_PROCESS_ID_NOTSERVERDATA, getActivity());
		pj.execute(params);
	}
		
	public void DeleteAnswerFolder(String path){
		File file = new File(path);
		File[] childFileList = file.listFiles();
		for(File childFile : childFileList){
			if(childFile.isDirectory()){
				DeleteAnswerFolder(childFile.getAbsolutePath());
			}else{
				childFile.delete();
			}
		}
		file.delete();
	}
	
	public void DeviceDialog(String msg){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.logindeviceconnert))
		.setMessage(msg)
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				//통신기기 등록
				setProgressDialogDismiss();
				setDeviceRequest();
			}
		})
		.setNegativeButton(getActivity().getString(R.string.no),new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void IdMissDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.login_msg_title))
		.setMessage(getActivity().getString(R.string.id_miss_msg))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void PassMissDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.login_msg_title))
		.setMessage(getActivity().getString(R.string.pass_miss_msg))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void IdAndPassMissDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.login_msg_title))
		.setMessage(getActivity().getString(R.string.id_pass_fail_msg))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void NetWorkErrorDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.network_error))
		.setMessage(getActivity().getString(R.string.network_check_noconnect))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
				getActivity().finish();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void loginTimeOutDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.login_msg_title))
		.setMessage(getActivity().getString(R.string.login_time_fail))
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}
	
	public void LoginMsgDialog(String msg){
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle(getActivity().getString(R.string.login_msg_title))
		.setMessage(msg)
		.setCancelable(false)
		.setPositiveButton(getActivity().getString(R.string.yes), new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		AlertDialog dialog = builder.create();
		if(!dialog.isShowing()){
			dialog.show();
		}
	}

	@Override
	public void onJsonPostExcute(String processID, String result) {
		// TODO Auto-generated method stub
		if(processID.equals(Constants.REQUEST_PROCESS_ID_LOGIN)){
			if(result != null && !result.equals("TimeOut")){
				loginresponse = result;
				try {
					
					JSONObject loginJson = new JSONObject(result);
					String login_companyId = loginJson.getString("companyId");
					String loginValue = loginJson.getString("loginValue");	
					userSeq = loginJson.getString("userSeq");
					String companySeq = loginJson.getString("companySeq");
					String authority = loginJson.getString("authority");
					String current_userId = loginJson.getString("userId");
					
					String last_response=SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_DATA, "");
					if(!last_response.equals("")){
						JSONObject last_loginJson = new JSONObject(last_response);
						String last_userId = last_loginJson.getString("userId");
						if(current_userId.equals(last_userId)){
							SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_DATA, result);
							SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_PASS, pass_txt.getText().toString());
						}
					}else{
						SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_DATA, result);
						SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_PASS, pass_txt.getText().toString());
					}
					
					if(loginValue.equals("5004")){
						setProgressDialogDismiss();
						String msg=loginJson.getString("loginMessage");
						DeviceDialog(msg);
					}else if(loginValue.equals("5009")){
						setProgressDialogDismiss();
						String msg=loginJson.getString("loginMessage");
						DeviceDialog(msg);
					}else if(loginValue.equals("5007")){
						setProgressDialogDismiss();
						//로그인 파일 체크
						String login_json_path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/jsonLoginFile";
						String id_path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/LoginFile";
						File id_file = new File(id_path);
						if(id_file.exists()){
							id_file.delete();
						}
						
						String loginTime_path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/LoginTimeFile";
						File loginTimeFile = new File(loginTime_path);
						if(loginTimeFile.exists()){
							loginTimeFile.delete();
						}
						
						String last_responses=Util.JsonFileRead(login_json_path);
						String id_pass_str=Util.JsonFileRead(id_path);
						long current_loginTime = System.currentTimeMillis(); 
							
						if(!last_responses.equals("")){
							//로그인 json 파일쓰기
							Util.JsonFileWrite(login_json_path, result);
						}
							
							
						if(id_pass_str.equals("")){
							//파일 쓰기
							JSONObject sendJson = new JSONObject();
							try {
								JSONArray array = new JSONArray();
								JSONObject obj = new JSONObject();
								obj.put("id", id);
								obj.put("pass", pass);
								array.put(obj);
								sendJson.put("Ids", array);
								Util.JsonFileWrite(id_path, sendJson.toString());
							} catch (JSONException e) {
								e.printStackTrace();
							}
						}
						//자동로그아웃 최초 파일쓰기
						String auto_path = Environment.getExternalStorageDirectory().getAbsolutePath()
								+File.separator+"Android"+File.separator+"data"+File.separator+getActivity().getPackageName()+File.separator+"autoLogout.txt";
						//최초 파일 쓰기
						long CurrentTiem = System.currentTimeMillis();
						String currentStringTime = String.valueOf(CurrentTiem);
						File autoFile = new File(auto_path);
						if(autoFile.exists()){
							autoFile.delete();
						}
						Util.FileWrite(auto_path, currentStringTime);
						
						
						//네트워크 안됐을때 체크후 보내기 
						String path = Environment.getExternalStorageDirectory().getAbsolutePath()
								+File.separator+"Android"+File.separator+"data"+File.separator+getActivity().getPackageName()+File.separator+"contents"+File.separator+"currentPage.txt";
						File currentFile = new File(path);
						if(currentFile.exists()){
							//라스트 페이지 전송
							setRequestNotNetworkLastPage();
						}
						ArrayList<BookMarkData> bookMarkArr = dbHelper.getBookMark(mDB, "constants");
						if(bookMarkArr.size() > 0){
							//북마크 전송
							setRequestNotNetWorkBookMarkData();
						}
						
						String answer_path = Environment.getExternalStorageDirectory().getAbsolutePath()
								+File.separator+"Android"+File.separator+"data"+File.separator+getActivity().getPackageName()+File.separator+"contents"+File.separator+"Answer";
						File answerFile = new File(answer_path);
						if(answerFile.isDirectory()){
							String data = getCollectAnwer();
							if(!data.equals("")){
								//answer파일 전송
								setRequestNotNetworkSerVerResult(data);
							}
						}
						
						//logData 전송
						setRequestLoginLogData();
						//userseq 저장 
						SharedPreferenceManager.putSharedPreferences(Constants.USER_SQ, userSeq);
						SharedPreferenceManager.putSharedPreferences(Constants.COMPANY_SQ, companySeq);
						SharedPreferenceManager.putSharedPreferences(Constants.LOGIN_JSON, result);
						Log.e("login_companyId", login_companyId);
						Log.e("getString login_id", Constants.COMPANY_ID);
						
						setProgressDialogDismiss();
						setRequestNotifications();
					}else{
						setProgressDialogDismiss();
						String msg=loginJson.getString("loginMessage");						//
						LoginMsgDialog(msg);
					}					
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				//네트워크 안됐을때
				setProgressDialogDismiss();			
				if(id.equals("") && !pass.equals("")){
					IdMissDialog();
				}else if(!id.equals("")  && pass.equals("")){
					PassMissDialog();
				}else if(id.equals("") && pass.equals("")){
					IdMissDialog();
				}else if(!id.equals("") && !pass.equals("")){
					String id_path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/LoginFile";
					String id_json = Util.JsonFileRead(id_path);
					boolean id_state = false;
					boolean pass_state = false;
					if(id_json.equals("")){
						NetWorkErrorDialog();
					}else{
						try {
							JSONObject obj = new JSONObject(id_json);
							JSONArray array=obj.getJSONArray("Ids");
							for(int i=0; i< array.length(); i++){
								JSONObject item=array.getJSONObject(i);
								String ids=item.getString("id");
								String passes = item.getString("pass");
								if(ids.equals(id) && passes.equals(pass)){
									//시간비교
//									String loginTime=item.getString("loginTime");
//									long loginTimeL = Long.parseLong(loginTime);
									String loginTime_path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/LoginTimeFile";
									String startTime=Util.JsonFileRead(loginTime_path);
//									String loginTime=item.getString(startTime);
									if(startTime.equals("")){
										NetWorkErrorDialog();
										return;
									}
									long loginTimeL = Long.parseLong(startTime);
									long currentTime = System.currentTimeMillis();
									String path = "data/data/"+getActivity().getPackageName()+File.separator+"databases/jsonLoingDevideFile";
									String loginDevideJson=Util.JsonFileRead(path);
									JSONArray jsonArr = new JSONArray(loginDevideJson);
									JSONObject Json=jsonArr.getJSONObject(0);
									JSONObject jsonObj=Json.getJSONObject("appInfo");
									String DivideLoginTime=jsonObj.getString("loginTime");
									long divideTime = 0;
									if(!DivideLoginTime.equals("null")){
										divideTime = Long.parseLong(DivideLoginTime);
										divideTime = divideTime*(60*1000);
									}
									long SystemTime = Math.round((currentTime - loginTimeL)/1000L);
									long SystemdurationTime = SystemTime * 1000;
									if(SystemdurationTime > divideTime && !DivideLoginTime.equals("null")){
										//msg 수정
										loginTimeOutDialog();
										id_state = true;
									}else if(DivideLoginTime.equals("null")){
										//메인화면 이동
										mListener.goMainActivity(true);
										id_state = true;
									}else{
										//메인화면 이동
										mListener.goMainActivity(true);
										id_state = true;
									}									
									break;
								}else{
									IdAndPassMissDialog();
								}
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
//				String id = id_txt.getText().toString();
//				String pass = pass_txt.getText().toString();
//				String lastLoginResponse = SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_DATA, "");
//				JSONObject loginValue;
//				String lastId = null;
//				try {
//					loginValue = new JSONObject(lastLoginResponse);
//					lastId=loginValue.getString("userId");
//				} catch (JSONException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				
//				if(id.equals(lastId) && pass.equals(SharedPreferenceManager.getSharedPreferences(Constants.LAST_LOGIN_PASS, ""))){
//					if(loginRequest != null){
//						loginRequest.requestCancel();
//						loginRequest = null;
//					}
//					Log.e("LoginFail", String.valueOf(errorCode));
//						setProgressDialogDismiss();
//						if(loginRequest != null){
//							loginRequest.requestCancel();
//							loginRequest = null;
//						}
//						String path = Constants.CONTENT_DOWNLOAD_FOLER+"data"+File.separator+getActivity().getPackageName()+File.separator+"startTime.txt";
//						File startFile = new File(path);						
//						if(!startFile.exists()){
//							setProgressDialogDismiss();
//							long startTime = System.currentTimeMillis();
//							String startTimeString=String.valueOf(startTime);
//							Util.FileWrite(path, startTimeString);
//							mListener.goMainActivity(true);
//						}else{
//							setProgressDialogDismiss();
//							String startTime = Util.FileRead(path);
//							long startTimeLong = Long.parseLong(startTime);
//							long currentTime = System.currentTimeMillis();
//							long durationTime= (currentTime - startTimeLong ) / 1000;
//							Log.e("durationTime", String.valueOf(durationTime));
//							long settingTime = Long.parseLong(getActivity().getString(R.string.login_second_time));
//							if(durationTime > settingTime){
//								//로그인 못함
//								Toast.makeText(getActivity(), getActivity().getString(R.string.network_check_noconnect), Toast.LENGTH_SHORT).show();
//							}else{
//								//gomain
//								mListener.goMainActivity(true);
//							}
//						}
//				}else{
//					setProgressDialogDismiss();
//					Toast.makeText(getActivity(), getActivity().getString(R.string.login_fail), Toast.LENGTH_SHORT).show();
//				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_DEVICEDATA)){
			//디바이스 관리자 데이터 정보통신
			setProgressDialogDismiss();
			if(result != null && !result.equals("TimeOut")){
				try {
					JSONObject responseJson = new JSONObject(result);
					String success = responseJson.getString("success");
					if(success.equals("5000")){
						//성공
						Log.e(Constants.REQUEST_PROCESS_ID_DEVICEDATA, "sucess");
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_LOGINDATA)){
			//로그인 정보
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					Log.e(Constants.REQUEST_PROCESS_ID_LOGINDATA, "sucess");
				}else{
					Log.e(Constants.REQUEST_PROCESS_ID_LOGINDATA, "fail");
				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_LOGINDATA)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_DATA, loginresponse);
					SharedPreferenceManager.putSharedPreferences(Constants.LAST_LOGIN_PASS, pass_txt.getText().toString());
					Log.e("login", "sucess");
				}else{
					Log.e("login", "fail");
				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_NOTIFICATION)){
			if(result != null && !result.equals("TimeOut")){
				try{
					JSONObject notiJson = new JSONObject(result);
					JSONArray notiJsonArray=notiJson.getJSONArray("noticeList");
					if(notiJsonArray.length() > 0){
						CustomNotificationDialog dialog = new CustomNotificationDialog(getActivity(), result, mListener);
						android.view.WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
						params.width = android.view.WindowManager.LayoutParams.MATCH_PARENT;
						params.height = android.view.WindowManager.LayoutParams.MATCH_PARENT;
						dialog.getWindow().setAttributes((android.view.WindowManager.LayoutParams)params);
						dialog.setCancelable(false);
						dialog.show();
					}else{
						//
						mListener.goMainActivity(false);
					}
				}catch(JSONException e){
					e.printStackTrace();
				}
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_NOTLASTPAGE)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				String lastPage=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					//라스트 페이지 파일 삭제
					setProgressDialogDismiss();
					Log.e("notNetworkLastPage", "success");
					
					String path = Environment.getExternalStorageDirectory().getAbsolutePath()
							+File.separator+"Android"+File.separator+"data"+File.separator+getActivity().getPackageName()+File.separator+"contents"+File.separator+"currentPage.txt";
					File currentPageFile = new File(path);
					if(currentPageFile.exists()){
						currentPageFile.delete();
					}
				}else{
					//라스트 페이지 파일 삭제
					setProgressDialogDismiss();
				}	
			}else{
				setProgressDialogDismiss();
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_NOTBOOKMARKDATA)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					//성공
					setProgressDialogDismiss();
					Log.e("notNetworkBookMark", "success");
					//삭제
					dbHelper.deleteBookMarkTable(mDB);
				}else{
					setProgressDialogDismiss();
				}	
			}else{
				setProgressDialogDismiss();
			}
		}else if(processID.equals(Constants.REQUEST_PROCESS_ID_NOTSERVERDATA)){
			if(result != null && !result.equals("TimeOut")){
				String success=null;
				try {
					JSONObject responseLog = new JSONObject(result);
					success = responseLog.getString("success");	
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(success.equals("5000")){
					setProgressDialogDismiss();
					//성공
					//Ansewer폴더 삭제
					String path = Environment.getExternalStorageDirectory().getAbsolutePath()
							+File.separator+"Android"+File.separator+"data"+File.separator+getActivity().getPackageName()+File.separator+"contents"+File.separator+"Answer";
					File answerDiretory = new File(path);
					if(answerDiretory.isDirectory()){
						DeleteAnswerFolder(path);
					}
				}else{
					Log.e("serverData", "requestFail");
				}	
			}else{
				setProgressDialogDismiss();
			}
		}
	}
}
